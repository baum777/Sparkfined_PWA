export function sanityCheck(bullets, payload) {
  // naive: ensure percent strings are reasonable; placeholder
  return bullets.map(b => b);
}
