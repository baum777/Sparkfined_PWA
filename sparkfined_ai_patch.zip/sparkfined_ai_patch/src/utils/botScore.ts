export function computeBotScore(post) {
  let score = 0.0;
  const a = post.author || {};
  if ((a.age_days || 0) < 7) score += 0.25;
  if ((a.followers || 0) < 10) score += 0.15;
  if ((post.post_frequency_per_day || 0) > 50) score += 0.2;
  if (post.repeated) score += 0.3;
  if (post.source_type === 'api' || post.source_type === 'webhook') score += 0.4;
  if ((a.verified) === true) score -= 0.3;
  return Math.min(Math.max(score, 0), 1);
}
