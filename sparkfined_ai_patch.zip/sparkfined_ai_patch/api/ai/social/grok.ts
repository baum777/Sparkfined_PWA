// Minimal Next.js-like handler (for demo). In your environment adjust exports accordingly.
import { callGrok } from '../../src/model_clients/grok_client';
export default async function handler(req, res) {
  const body = req.body || {};
  const { query, posts, mode='newest', limit=10 } = body;
  if (!query && !posts) return res.status(400).json({ ok:false, error:'missing query/posts' });
  const payload = { query, posts, mode, limit };
  try {
    const grok = await callGrok('social_analysis', payload);
    return res.status(200).json({ ok:true, result: grok });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok:false, error: e.message });
  }
}
