import { describe, it, expect } from 'vitest';
import { shouldSample } from '../src/orchestrator';

describe('sampling helper', () => {
  it('returns boolean', () => {
    const v = shouldSample(0.5);
    expect(typeof v).toBe('boolean');
  });
});
