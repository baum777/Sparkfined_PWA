import { describe, it, expect } from 'vitest';
import { computeBotScore } from '../src/utils/botScore';

describe('botScore heuristics', () => {
  it('flags obvious bot', () => {
    const post = { author: { age_days: 1, followers: 2 }, repeated: true, source_type: 'api', text: 'signal buy' };
    const s = computeBotScore(post);
    expect(s).toBeGreaterThanOrEqual(0.5);
  });
  it('flags human low score', () => {
    const post = { author: { age_days: 400, followers: 1200 }, repeated: false, source_type: 'web' };
    const s = computeBotScore(post);
    expect(s).toBeLessThan(0.3);
  });
});
