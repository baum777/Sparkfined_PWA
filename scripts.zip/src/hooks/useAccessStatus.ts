/**
 * useAccessStatus Hook
 * 
 * Re-export from AccessProvider for convenience
 */

export { useAccessStatus } from '../store/AccessProvider'
