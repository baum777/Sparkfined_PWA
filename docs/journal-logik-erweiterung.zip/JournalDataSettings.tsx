/**
 * Journal Settings UI - Extended Data Configuration
 * 
 * Ermöglicht User-Konfiguration welche Extended Parameters
 * automatisch bei jedem Entry erfasst werden sollen
 */

import React, { useState } from 'react';
import { useStore } from '@/store';

// ============================================================================
// TYPES
// ============================================================================

interface JournalDataConfig {
  // Market Data
  captureMarketCap: boolean;
  captureMarketCapCategory: boolean;
  captureVolume: boolean;
  captureVolumeToMcapRatio: boolean;
  capturePriceChanges: boolean;
  customPriceChangeTimeframes: string[];
  capturePriceATH: boolean;
  captureTokenAge: boolean;
  captureTokenMaturity: boolean;
  captureHolderCount: boolean;
  
  // Technical Data
  captureRSI: boolean;
  captureMacd: boolean;
  captureVolumeSpike: boolean;
  captureBreakout: boolean;
  
  // On-Chain Data
  captureHolderDistribution: boolean;
  captureWhaleConcentration: boolean;
  captureLiquidityPools: boolean;
  captureTxMetrics: boolean;
}

interface TimeframeOption {
  value: string;
  label: string;
  description: string;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const AVAILABLE_TIMEFRAMES: TimeframeOption[] = [
  { value: '15s', label: '15 Seconds', description: 'Ultra-short scalping' },
  { value: '30s', label: '30 Seconds', description: 'Short-term momentum' },
  { value: '1m', label: '1 Minute', description: 'Quick moves' },
  { value: '5m', label: '5 Minutes', description: 'Intraday swings' },
  { value: '15m', label: '15 Minutes', description: 'Short trends' },
  { value: '1h', label: '1 Hour', description: 'Hourly trends' },
  { value: '4h', label: '4 Hours', description: 'Mid-term trends' },
];

const DEFAULT_CONFIG: JournalDataConfig = {
  // Market Data - Defaults enabled
  captureMarketCap: true,
  captureMarketCapCategory: true,
  captureVolume: true,
  captureVolumeToMcapRatio: true,
  capturePriceChanges: true,
  customPriceChangeTimeframes: ['5m', '15m', '1h', '4h'],
  capturePriceATH: true,
  captureTokenAge: true,
  captureTokenMaturity: true,
  captureHolderCount: true,
  
  // Technical Data - Defaults enabled
  captureRSI: true,
  captureMacd: true,
  captureVolumeSpike: true,
  captureBreakout: true,
  
  // On-Chain Data - Defaults enabled
  captureHolderDistribution: true,
  captureWhaleConcentration: true,
  captureLiquidityPools: true,
  captureTxMetrics: true,
};

// ============================================================================
// COMPONENT
// ============================================================================

export function JournalDataSettings() {
  const { journalConfig, setJournalConfig } = useStore();
  const [config, setConfig] = useState<JournalDataConfig>(
    journalConfig || DEFAULT_CONFIG
  );
  const [showTimeframeModal, setShowTimeframeModal] = useState(false);
  const [customTimeframe, setCustomTimeframe] = useState('');

  // Berechne Storage Impact
  const estimatedBytesPerEntry = calculateStorageImpact(config);

  // Handler: Toggle einzelne Option
  const toggleOption = (key: keyof JournalDataConfig) => {
    setConfig(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Handler: Timeframe hinzufügen/entfernen
  const toggleTimeframe = (timeframe: string) => {
    setConfig(prev => ({
      ...prev,
      customPriceChangeTimeframes: prev.customPriceChangeTimeframes.includes(timeframe)
        ? prev.customPriceChangeTimeframes.filter(tf => tf !== timeframe)
        : [...prev.customPriceChangeTimeframes, timeframe]
    }));
  };

  // Handler: Custom Timeframe hinzufügen
  const addCustomTimeframe = () => {
    if (!customTimeframe.trim()) return;
    
    // Validierung: Format "15s", "1m", "4h"
    const isValid = /^(\d+)(s|m|h)$/.test(customTimeframe);
    if (!isValid) {
      alert('Invalid format. Use: 15s, 1m, 4h, etc.');
      return;
    }
    
    setConfig(prev => ({
      ...prev,
      customPriceChangeTimeframes: [
        ...prev.customPriceChangeTimeframes,
        customTimeframe
      ]
    }));
    
    setCustomTimeframe('');
    setShowTimeframeModal(false);
  };

  // Handler: Speichern
  const handleSave = () => {
    setJournalConfig(config);
    // Toast notification
    showToast({
      title: 'Settings Saved',
      message: 'Journal data configuration updated',
      duration: 3000
    });
  };

  // Handler: Reset zu Defaults
  const handleReset = () => {
    setConfig(DEFAULT_CONFIG);
  };

  // Handler: Minimal Preset
  const handleMinimal = () => {
    setConfig({
      ...DEFAULT_CONFIG,
      captureMarketCapCategory: false,
      captureVolumeToMcapRatio: false,
      capturePriceChanges: false,
      customPriceChangeTimeframes: [],
      capturePriceATH: false,
      captureTokenMaturity: false,
      captureMacd: false,
      captureVolumeSpike: false,
      captureBreakout: false,
      captureWhaleConcentration: false,
      captureLiquidityPools: false,
      captureTxMetrics: false,
    });
  };

  // Handler: Maximum Preset
  const handleMaximum = () => {
    setConfig({
      ...DEFAULT_CONFIG,
      customPriceChangeTimeframes: AVAILABLE_TIMEFRAMES.map(tf => tf.value),
    });
  };

  return (
    <div className="journal-data-settings">
      {/* Header */}
      <div className="settings-header">
        <h2>📊 Extended Entry Data</h2>
        <p className="text-sm text-gray-400">
          Configure which market data is automatically captured for each trade entry
        </p>
      </div>

      {/* Quick Presets */}
      <div className="presets-row">
        <button onClick={handleMinimal} className="preset-btn">
          Minimal
        </button>
        <button onClick={handleReset} className="preset-btn">
          Default
        </button>
        <button onClick={handleMaximum} className="preset-btn">
          Maximum
        </button>
      </div>

      {/* Market Context Section */}
      <section className="settings-section">
        <h3>🏦 Market Context</h3>
        
        <SettingToggle
          label="Market Cap"
          description="Total market capitalization in USD"
          checked={config.captureMarketCap}
          onChange={() => toggleOption('captureMarketCap')}
        />
        
        <SettingToggle
          label="Market Cap Category"
          description="Classification: Mega, Large, Mid, Small, Micro, Nano"
          checked={config.captureMarketCapCategory}
          onChange={() => toggleOption('captureMarketCapCategory')}
          disabled={!config.captureMarketCap}
        />
        
        <SettingToggle
          label="24h Volume"
          description="Trading volume over last 24 hours"
          checked={config.captureVolume}
          onChange={() => toggleOption('captureVolume')}
        />
        
        <SettingToggle
          label="Volume/MCap Ratio"
          description="Volume as percentage of market cap (liquidity indicator)"
          checked={config.captureVolumeToMcapRatio}
          onChange={() => toggleOption('captureVolumeToMcapRatio')}
          disabled={!config.captureVolume || !config.captureMarketCap}
        />
        
        <SettingToggle
          label="Price Changes (Multi-Timeframe)"
          description="Track price movement across custom timeframes"
          checked={config.capturePriceChanges}
          onChange={() => toggleOption('capturePriceChanges')}
        />
        
        {config.capturePriceChanges && (
          <div className="timeframe-selector">
            <label className="text-sm text-gray-400">Active Timeframes:</label>
            <div className="timeframe-chips">
              {AVAILABLE_TIMEFRAMES.map(tf => (
                <TimeframeChip
                  key={tf.value}
                  timeframe={tf}
                  isSelected={config.customPriceChangeTimeframes.includes(tf.value)}
                  onToggle={() => toggleTimeframe(tf.value)}
                />
              ))}
            </div>
            
            {/* Custom Timeframe Input */}
            <button
              onClick={() => setShowTimeframeModal(true)}
              className="add-custom-btn"
            >
              + Add Custom Timeframe
            </button>
            
            {/* Custom Timeframes anzeigen */}
            {config.customPriceChangeTimeframes
              .filter(tf => !AVAILABLE_TIMEFRAMES.find(opt => opt.value === tf))
              .map(tf => (
                <div key={tf} className="custom-timeframe-chip">
                  {tf}
                  <button onClick={() => toggleTimeframe(tf)}>×</button>
                </div>
              ))}
          </div>
        )}
        
        <SettingToggle
          label="ATH Distance"
          description="Price distance from all-time high"
          checked={config.capturePriceATH}
          onChange={() => toggleOption('capturePriceATH')}
        />
        
        <SettingToggle
          label="Token Age"
          description="Days since token launch"
          checked={config.captureTokenAge}
          onChange={() => toggleOption('captureTokenAge')}
        />
        
        <SettingToggle
          label="Token Maturity"
          description="Classification: Fresh, New, Established, Mature"
          checked={config.captureTokenMaturity}
          onChange={() => toggleOption('captureTokenMaturity')}
          disabled={!config.captureTokenAge}
        />
        
        <SettingToggle
          label="Holder Count"
          description="Number of unique wallet addresses holding token"
          checked={config.captureHolderCount}
          onChange={() => toggleOption('captureHolderCount')}
        />
      </section>

      {/* Technical Indicators Section */}
      <section className="settings-section">
        <h3>📈 Technical Indicators</h3>
        
        <SettingToggle
          label="RSI (14-period)"
          description="Relative Strength Index + Overbought/Oversold classification"
          checked={config.captureRSI}
          onChange={() => toggleOption('captureRSI')}
        />
        
        <SettingToggle
          label="MACD Signal"
          description="Moving Average Convergence Divergence + Bullish/Bearish signal"
          checked={config.captureMacd}
          onChange={() => toggleOption('captureMacd')}
        />
        
        <SettingToggle
          label="Volume Spike"
          description="Detect abnormal volume (>200% of 20-day average)"
          checked={config.captureVolumeSpike}
          onChange={() => toggleOption('captureVolumeSpike')}
        />
        
        <SettingToggle
          label="Breakout Detection"
          description="Price breaking above resistance level (+5% threshold)"
          checked={config.captureBreakout}
          onChange={() => toggleOption('captureBreakout')}
        />
      </section>

      {/* On-Chain Metrics Section */}
      <section className="settings-section">
        <h3>⛓️ On-Chain Metrics (Solana)</h3>
        
        <SettingToggle
          label="Holder Distribution"
          description="Top 10 holders percentage (whale risk indicator)"
          checked={config.captureHolderDistribution}
          onChange={() => toggleOption('captureHolderDistribution')}
        />
        
        <SettingToggle
          label="Whale Concentration"
          description="Risk classification: Critical, High, Medium, Low"
          checked={config.captureWhaleConcentration}
          onChange={() => toggleOption('captureWhaleConcentration')}
          disabled={!config.captureHolderDistribution}
        />
        
        <SettingToggle
          label="DEX Liquidity Pools"
          description="Liquidity distribution across Raydium, Orca, Meteora, Phoenix"
          checked={config.captureLiquidityPools}
          onChange={() => toggleOption('captureLiquidityPools')}
        />
        
        <SettingToggle
          label="Transaction Metrics"
          description="Slippage, gas fees, priority fees, confirmation time"
          checked={config.captureTxMetrics}
          onChange={() => toggleOption('captureTxMetrics')}
        />
      </section>

      {/* Storage Impact */}
      <div className="storage-impact">
        <span className="text-sm text-gray-400">
          💾 Estimated storage: ~{estimatedBytesPerEntry} bytes per entry
        </span>
        <span className="text-xs text-gray-500">
          ({(estimatedBytesPerEntry / 1024).toFixed(2)} KB per 1000 entries)
        </span>
      </div>

      {/* Action Buttons */}
      <div className="settings-actions">
        <button onClick={handleReset} className="btn-secondary">
          Reset to Default
        </button>
        <button onClick={handleSave} className="btn-primary">
          Save Settings
        </button>
      </div>

      {/* Custom Timeframe Modal */}
      {showTimeframeModal && (
        <TimeframeModal
          value={customTimeframe}
          onChange={setCustomTimeframe}
          onAdd={addCustomTimeframe}
          onClose={() => setShowTimeframeModal(false)}
        />
      )}
    </div>
  );
}

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

interface SettingToggleProps {
  label: string;
  description: string;
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
}

function SettingToggle({ label, description, checked, onChange, disabled }: SettingToggleProps) {
  return (
    <div className={`setting-toggle ${disabled ? 'disabled' : ''}`}>
      <div className="toggle-content">
        <label className="toggle-label">{label}</label>
        <span className="toggle-description">{description}</span>
      </div>
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        disabled={disabled}
        className="toggle-switch"
      />
    </div>
  );
}

interface TimeframeChipProps {
  timeframe: TimeframeOption;
  isSelected: boolean;
  onToggle: () => void;
}

function TimeframeChip({ timeframe, isSelected, onToggle }: TimeframeChipProps) {
  return (
    <div
      className={`timeframe-chip ${isSelected ? 'selected' : ''}`}
      onClick={onToggle}
      title={timeframe.description}
    >
      <span>{timeframe.label}</span>
      {isSelected && <span className="checkmark">✓</span>}
    </div>
  );
}

interface TimeframeModalProps {
  value: string;
  onChange: (value: string) => void;
  onAdd: () => void;
  onClose: () => void;
}

function TimeframeModal({ value, onChange, onAdd, onClose }: TimeframeModalProps) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <h3>Add Custom Timeframe</h3>
        <p className="text-sm text-gray-400">
          Format: Number + Unit (s=seconds, m=minutes, h=hours)
        </p>
        
        <div className="input-group">
          <input
            type="text"
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder="e.g. 15s, 3m, 2h"
            className="timeframe-input"
            autoFocus
          />
          
          <div className="example-chips">
            <span onClick={() => onChange('15s')}>15s</span>
            <span onClick={() => onChange('30s')}>30s</span>
            <span onClick={() => onChange('2m')}>2m</span>
            <span onClick={() => onChange('10m')}>10m</span>
            <span onClick={() => onChange('30m')}>30m</span>
            <span onClick={() => onChange('2h')}>2h</span>
          </div>
        </div>
        
        <div className="modal-actions">
          <button onClick={onClose} className="btn-secondary">
            Cancel
          </button>
          <button onClick={onAdd} className="btn-primary">
            Add Timeframe
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function calculateStorageImpact(config: JournalDataConfig): number {
  let bytes = 150; // Core data baseline
  
  // Market Data
  if (config.captureMarketCap) bytes += 8;
  if (config.captureMarketCapCategory) bytes += 10;
  if (config.captureVolume) bytes += 8;
  if (config.captureVolumeToMcapRatio) bytes += 8;
  if (config.capturePriceChanges) {
    bytes += config.customPriceChangeTimeframes.length * 12; // ~12 bytes per timeframe
  }
  if (config.capturePriceATH) bytes += 16;
  if (config.captureTokenAge) bytes += 4;
  if (config.captureTokenMaturity) bytes += 12;
  if (config.captureHolderCount) bytes += 4;
  
  // Technical Data
  if (config.captureRSI) bytes += 16;
  if (config.captureMacd) bytes += 32;
  if (config.captureVolumeSpike) bytes += 12;
  if (config.captureBreakout) bytes += 4;
  
  // On-Chain Data
  if (config.captureHolderDistribution) bytes += 8;
  if (config.captureWhaleConcentration) bytes += 10;
  if (config.captureLiquidityPools) bytes += 40;
  if (config.captureTxMetrics) bytes += 32;
  
  return bytes;
}

function showToast(options: {
  title: string;
  message: string;
  duration: number;
}) {
  // Toast notification implementation
  console.log('Toast:', options);
}

// ============================================================================
// STYLES (Tailwind + Custom CSS)
// ============================================================================

const styles = `
.journal-data-settings {
  @apply max-w-4xl mx-auto p-6 space-y-8;
}

.settings-header h2 {
  @apply text-2xl font-bold mb-2;
}

.presets-row {
  @apply flex gap-3;
}

.preset-btn {
  @apply px-4 py-2 rounded-lg border border-gray-700 
         hover:border-spark-500 transition-colors;
}

.settings-section {
  @apply bg-void-900 rounded-xl p-6 space-y-4;
}

.settings-section h3 {
  @apply text-lg font-semibold mb-4 flex items-center gap-2;
}

.setting-toggle {
  @apply flex justify-between items-center py-3 
         border-b border-gray-800 last:border-0;
}

.setting-toggle.disabled {
  @apply opacity-40 cursor-not-allowed;
}

.toggle-content {
  @apply flex-1 pr-4;
}

.toggle-label {
  @apply block font-medium mb-1;
}

.toggle-description {
  @apply block text-sm text-gray-400;
}

.toggle-switch {
  @apply w-12 h-6 rounded-full bg-gray-700 
         checked:bg-spark-500 transition-colors
         relative cursor-pointer appearance-none;
}

.toggle-switch::after {
  @apply content-[''] absolute top-1 left-1 w-4 h-4 
         rounded-full bg-white transition-transform;
}

.toggle-switch:checked::after {
  @apply translate-x-6;
}

.timeframe-selector {
  @apply ml-6 mt-2 space-y-3;
}

.timeframe-chips {
  @apply flex flex-wrap gap-2;
}

.timeframe-chip {
  @apply px-3 py-1.5 rounded-lg border border-gray-700
         cursor-pointer transition-all hover:border-spark-500;
}

.timeframe-chip.selected {
  @apply bg-spark-500 border-spark-500 text-black font-medium;
}

.timeframe-chip .checkmark {
  @apply ml-1;
}

.add-custom-btn {
  @apply text-sm text-spark-500 hover:text-spark-400 mt-2;
}

.custom-timeframe-chip {
  @apply inline-flex items-center gap-2 px-3 py-1 
         rounded-lg bg-violet-500/20 border border-violet-500;
}

.custom-timeframe-chip button {
  @apply hover:text-red-500;
}

.storage-impact {
  @apply flex justify-between items-center p-4 
         bg-void-900 rounded-lg border border-gray-800;
}

.settings-actions {
  @apply flex justify-end gap-3;
}

.btn-secondary {
  @apply px-6 py-2.5 rounded-lg border border-gray-700
         hover:border-gray-600 transition-colors;
}

.btn-primary {
  @apply px-6 py-2.5 rounded-lg bg-spark-500 text-black
         font-medium hover:bg-spark-400 transition-colors;
}

.modal-overlay {
  @apply fixed inset-0 bg-black/80 flex items-center justify-center z-50;
}

.modal-content {
  @apply bg-void-900 rounded-xl p-6 max-w-md w-full space-y-4;
}

.modal-content h3 {
  @apply text-xl font-bold;
}

.input-group {
  @apply space-y-3;
}

.timeframe-input {
  @apply w-full px-4 py-2 bg-void-800 border border-gray-700
         rounded-lg focus:border-spark-500 outline-none;
}

.example-chips {
  @apply flex flex-wrap gap-2;
}

.example-chips span {
  @apply px-3 py-1 bg-void-800 rounded-lg cursor-pointer
         hover:bg-spark-500 hover:text-black transition-colors;
}

.modal-actions {
  @apply flex justify-end gap-3;
}
`;
