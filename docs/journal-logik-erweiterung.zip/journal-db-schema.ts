/**
 * Sparkfined - Journal Database Schema & Store
 * 
 * IndexedDB via Dexie.js für lokales Speichern von:
 * - Pending Entries (aktive 24h Fenster)
 * - Archived Entries (Logbuch)
 * - Journal Entries (bestätigte, enriched Entries)
 * - User Config
 */

import Dexie, { Table } from 'dexie';

// ============================================================================
// TYPE DEFINITIONS (Import from logic file)
// ============================================================================

interface CoreEntryData {
  tokenAddress: string;
  tokenSymbol: string;
  tokenName: string;
  timestamp: number;
  txHash: string;
  positionSizeUSD: number;
  positionSizeToken: number;
  entryPrice: number;
  exitPrice?: number;
  dexUsed: 'Jupiter' | 'Raydium' | 'Orca' | 'Meteora' | 'Phoenix';
}

interface ExtendedMarketData {
  marketCap: number;
  marketCapCategory: 'Mega' | 'Large' | 'Mid' | 'Small' | 'Micro' | 'Nano';
  volume24h: number;
  volumeToMcapRatio: number;
  liquidityUSD: number;
  priceChanges: Record<string, number>;
  priceATH: number;
  priceDistanceFromATH: number;
  tokenAge: number;
  tokenMaturity: 'Fresh' | 'New' | 'Established' | 'Mature';
  holderCount: number;
}

interface ExtendedTechnicalData {
  rsi14: number;
  rsiCondition: 'Overbought' | 'Neutral' | 'Oversold';
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  macdCondition: 'Bullish' | 'Bearish' | 'Neutral';
  volumeSpike: boolean;
  volumeSpikePercent: number;
  isPriceBreakout: boolean;
}

interface ExtendedOnchainData {
  top10HoldersPercent: number;
  whaleConcentration: 'Critical' | 'High' | 'Medium' | 'Low';
  holderGrowth24h: number;
  liquidityPools: {
    raydium?: number;
    orca?: number;
    meteora?: number;
    phoenix?: number;
  };
  slippage: number;
  gasUsedSOL: number;
  priorityFee?: number;
  txConfirmationTime: number;
}

interface Transaction {
  type: 'BUY' | 'SELL';
  timestamp: number;
  amountUSD: number;
  amountToken: number;
  price: number;
  hash: string;
}

interface JournalEntry {
  id: string;
  core: CoreEntryData;
  transactions: Transaction[];
  marketData?: ExtendedMarketData;
  technicalData?: ExtendedTechnicalData;
  onchainData?: ExtendedOnchainData;
  userNotes?: string;
  emotion?: 'FOMO' | 'Setup' | 'Revenge' | 'Fear' | 'Greed';
  tags?: string[];
  voiceNoteBase64?: string;
  screenshots?: string[];
  status: 'pending' | 'closed' | 'archived' | 'confirmed';
  createdAt: number;
  expiresAt: number;
  closedAt?: number;
  archivedAt?: number;
  confirmedAt?: number;
  unrealizedPnL?: number;
  realizedPnL?: number;
  totalCostBasis: number;
  avgEntryPrice: number;
}

interface PendingEntry extends JournalEntry {
  status: 'pending';
}

interface ArchivedEntry extends JournalEntry {
  status: 'archived';
  archivedAt: number;
  archiveReason: 'full_exit' | 'expired' | 'manual';
}

interface ConfirmedEntry extends JournalEntry {
  status: 'confirmed';
  confirmedAt: number;
}

interface JournalDataConfig {
  captureMarketCap: boolean;
  captureMarketCapCategory: boolean;
  captureVolume: boolean;
  captureVolumeToMcapRatio: boolean;
  capturePriceChanges: boolean;
  customPriceChangeTimeframes: string[];
  capturePriceATH: boolean;
  captureTokenAge: boolean;
  captureTokenMaturity: boolean;
  captureHolderCount: boolean;
  captureRSI: boolean;
  captureMacd: boolean;
  captureVolumeSpike: boolean;
  captureBreakout: boolean;
  captureHolderDistribution: boolean;
  captureWhaleConcentration: boolean;
  captureLiquidityPools: boolean;
  captureTxMetrics: boolean;
}

interface UserWallet {
  address: string;
  chain: 'solana';
  label: string;
  isActive: boolean;
  addedAt: number;
}

interface UserSettings {
  id: string;
  wallets: UserWallet[];
  journalConfig: JournalDataConfig;
  autoTracking: {
    enabled: boolean;
    minTradeValueUSD: number;
    excludeTokens: string[];
  };
  updatedAt: number;
}

// ============================================================================
// DATABASE DEFINITION
// ============================================================================

class SparkfinedDatabase extends Dexie {
  // Tables
  pendingEntries!: Table<PendingEntry, string>;
  archivedEntries!: Table<ArchivedEntry, string>;
  confirmedEntries!: Table<ConfirmedEntry, string>;
  userSettings!: Table<UserSettings, string>;

  constructor() {
    super('sparkfined_journal_v1');

    this.version(1).stores({
      // Pending Entries (24h aktive Fenster)
      pendingEntries: `
        id,
        core.tokenAddress,
        core.tokenSymbol,
        status,
        createdAt,
        expiresAt,
        [core.tokenAddress+status],
        [status+expiresAt]
      `,

      // Archived Entries (Logbuch - expired oder full exit)
      archivedEntries: `
        id,
        core.tokenAddress,
        core.tokenSymbol,
        status,
        archivedAt,
        archiveReason,
        [core.tokenAddress+archivedAt],
        [archiveReason+archivedAt]
      `,

      // Confirmed Entries (User-enriched Journal Entries)
      confirmedEntries: `
        id,
        core.tokenAddress,
        core.tokenSymbol,
        confirmedAt,
        emotion,
        realizedPnL,
        [core.tokenSymbol+confirmedAt],
        [emotion+confirmedAt],
        [confirmedAt]
      `,

      // User Settings
      userSettings: 'id, updatedAt'
    });
  }
}

// Singleton Instance
export const db = new SparkfinedDatabase();

// ============================================================================
// ZUSTAND STORE
// ============================================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface JournalStore {
  // Pending Entries
  pendingEntries: PendingEntry[];
  loadPendingEntries: () => Promise<void>;
  addPendingEntry: (entry: PendingEntry) => Promise<void>;
  updatePendingEntry: (id: string, updates: Partial<PendingEntry>) => Promise<void>;
  deletePendingEntry: (id: string) => Promise<void>;

  // Archived Entries
  archivedEntries: ArchivedEntry[];
  loadArchivedEntries: () => Promise<void>;
  archiveEntry: (entry: PendingEntry, reason: ArchivedEntry['archiveReason']) => Promise<void>;
  recoverFromArchive: (id: string) => Promise<void>;

  // Confirmed Entries
  confirmedEntries: ConfirmedEntry[];
  loadConfirmedEntries: () => Promise<void>;
  confirmEntry: (
    entry: PendingEntry | ArchivedEntry,
    enrichment: {
      userNotes?: string;
      emotion?: ConfirmedEntry['emotion'];
      tags?: string[];
      voiceNoteBase64?: string;
      screenshots?: string[];
    }
  ) => Promise<void>;

  // User Settings
  userSettings: UserSettings | null;
  loadUserSettings: () => Promise<void>;
  updateUserSettings: (updates: Partial<UserSettings>) => Promise<void>;

  // Filters & Search
  filterBy: {
    symbol?: string;
    emotion?: string;
    dateRange?: [number, number];
    minPnL?: number;
    maxPnL?: number;
  };
  setFilter: (filter: JournalStore['filterBy']) => void;
  clearFilters: () => void;

  // Stats
  stats: {
    totalTrades: number;
    totalPnL: number;
    winRate: number;
    avgWin: number;
    avgLoss: number;
    bestTrade: number;
    worstTrade: number;
  };
  calculateStats: () => Promise<void>;
}

export const useJournalStore = create<JournalStore>()(
  persist(
    (set, get) => ({
      // Initial State
      pendingEntries: [],
      archivedEntries: [],
      confirmedEntries: [],
      userSettings: null,
      filterBy: {},
      stats: {
        totalTrades: 0,
        totalPnL: 0,
        winRate: 0,
        avgWin: 0,
        avgLoss: 0,
        bestTrade: 0,
        worstTrade: 0,
      },

      // ======================================================================
      // PENDING ENTRIES
      // ======================================================================

      loadPendingEntries: async () => {
        const entries = await db.pendingEntries
          .where('status')
          .equals('pending')
          .and(entry => entry.expiresAt > Date.now())
          .toArray();
        set({ pendingEntries: entries });
      },

      addPendingEntry: async (entry) => {
        await db.pendingEntries.add(entry);
        await get().loadPendingEntries();
      },

      updatePendingEntry: async (id, updates) => {
        await db.pendingEntries.update(id, updates);
        await get().loadPendingEntries();
      },

      deletePendingEntry: async (id) => {
        await db.pendingEntries.delete(id);
        await get().loadPendingEntries();
      },

      // ======================================================================
      // ARCHIVED ENTRIES
      // ======================================================================

      loadArchivedEntries: async () => {
        const entries = await db.archivedEntries
          .orderBy('archivedAt')
          .reverse()
          .limit(100) // Last 100 archived
          .toArray();
        set({ archivedEntries: entries });
      },

      archiveEntry: async (entry, reason) => {
        const archived: ArchivedEntry = {
          ...entry,
          status: 'archived',
          archivedAt: Date.now(),
          archiveReason: reason,
        };

        await db.archivedEntries.add(archived);
        await db.pendingEntries.delete(entry.id);
        await get().loadPendingEntries();
        await get().loadArchivedEntries();
      },

      recoverFromArchive: async (id) => {
        const entry = await db.archivedEntries.get(id);
        if (!entry) return;

        const recovered: PendingEntry = {
          ...entry,
          status: 'pending',
          expiresAt: Date.now() + 24 * 60 * 60 * 1000, // +24h
        };

        await db.pendingEntries.add(recovered);
        await db.archivedEntries.delete(id);
        await get().loadPendingEntries();
        await get().loadArchivedEntries();
      },

      // ======================================================================
      // CONFIRMED ENTRIES
      // ======================================================================

      loadConfirmedEntries: async () => {
        const { filterBy } = get();
        let query = db.confirmedEntries.orderBy('confirmedAt').reverse();

        // Apply Filters
        if (filterBy.symbol) {
          query = query.filter(e => e.core.tokenSymbol === filterBy.symbol);
        }
        if (filterBy.emotion) {
          query = query.filter(e => e.emotion === filterBy.emotion);
        }
        if (filterBy.dateRange) {
          const [start, end] = filterBy.dateRange;
          query = query.filter(e => 
            e.confirmedAt >= start && e.confirmedAt <= end
          );
        }
        if (filterBy.minPnL !== undefined) {
          query = query.filter(e => (e.realizedPnL || 0) >= filterBy.minPnL!);
        }
        if (filterBy.maxPnL !== undefined) {
          query = query.filter(e => (e.realizedPnL || 0) <= filterBy.maxPnL!);
        }

        const entries = await query.toArray();
        set({ confirmedEntries: entries });
      },

      confirmEntry: async (entry, enrichment) => {
        const confirmed: ConfirmedEntry = {
          ...entry,
          ...enrichment,
          status: 'confirmed',
          confirmedAt: Date.now(),
        };

        await db.confirmedEntries.add(confirmed);

        // Entferne aus pending/archived
        if (entry.status === 'pending') {
          await db.pendingEntries.delete(entry.id);
        } else if (entry.status === 'archived') {
          await db.archivedEntries.delete(entry.id);
        }

        await get().loadConfirmedEntries();
        await get().loadPendingEntries();
        await get().loadArchivedEntries();
        await get().calculateStats();
      },

      // ======================================================================
      // USER SETTINGS
      // ======================================================================

      loadUserSettings: async () => {
        const settings = await db.userSettings.get('user_settings_v1');
        set({ userSettings: settings || null });
      },

      updateUserSettings: async (updates) => {
        const current = get().userSettings || {
          id: 'user_settings_v1',
          wallets: [],
          journalConfig: {} as JournalDataConfig,
          autoTracking: {
            enabled: true,
            minTradeValueUSD: 10,
            excludeTokens: [],
          },
          updatedAt: Date.now(),
        };

        const updated = {
          ...current,
          ...updates,
          updatedAt: Date.now(),
        };

        await db.userSettings.put(updated);
        set({ userSettings: updated });
      },

      // ======================================================================
      // FILTERS
      // ======================================================================

      setFilter: (filter) => {
        set({ filterBy: { ...get().filterBy, ...filter } });
        get().loadConfirmedEntries();
      },

      clearFilters: () => {
        set({ filterBy: {} });
        get().loadConfirmedEntries();
      },

      // ======================================================================
      // STATS
      // ======================================================================

      calculateStats: async () => {
        const entries = await db.confirmedEntries.toArray();

        const totalTrades = entries.length;
        const pnls = entries.map(e => e.realizedPnL || 0);
        const wins = pnls.filter(p => p > 0);
        const losses = pnls.filter(p => p < 0);

        const totalPnL = pnls.reduce((sum, p) => sum + p, 0);
        const winRate = totalTrades > 0 ? (wins.length / totalTrades) * 100 : 0;
        const avgWin = wins.length > 0 
          ? wins.reduce((sum, p) => sum + p, 0) / wins.length 
          : 0;
        const avgLoss = losses.length > 0
          ? losses.reduce((sum, p) => sum + p, 0) / losses.length
          : 0;
        const bestTrade = pnls.length > 0 ? Math.max(...pnls) : 0;
        const worstTrade = pnls.length > 0 ? Math.min(...pnls) : 0;

        set({
          stats: {
            totalTrades,
            totalPnL,
            winRate,
            avgWin,
            avgLoss,
            bestTrade,
            worstTrade,
          },
        });
      },
    }),
    {
      name: 'sparkfined-journal-store',
      partialize: (state) => ({
        // Nur filterBy und userSettings persistieren
        filterBy: state.filterBy,
        userSettings: state.userSettings,
      }),
    }
  )
);

// ============================================================================
// INIT: Load Data on App Start
// ============================================================================

export async function initJournalStore() {
  const store = useJournalStore.getState();
  await Promise.all([
    store.loadPendingEntries(),
    store.loadArchivedEntries(),
    store.loadConfirmedEntries(),
    store.loadUserSettings(),
    store.calculateStats(),
  ]);
}

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Exportiert alle Confirmed Entries als JSON
 */
export async function exportJournalAsJSON(): Promise<string> {
  const entries = await db.confirmedEntries.toArray();
  return JSON.stringify(entries, null, 2);
}

/**
 * Exportiert als CSV
 */
export async function exportJournalAsCSV(): Promise<string> {
  const entries = await db.confirmedEntries.toArray();
  
  const headers = [
    'Date',
    'Symbol',
    'Entry Price',
    'Exit Price',
    'Position Size (USD)',
    'PnL (USD)',
    'PnL (%)',
    'Emotion',
    'Notes',
  ];

  const rows = entries.map(e => [
    new Date(e.confirmedAt).toISOString(),
    e.core.tokenSymbol,
    e.core.entryPrice,
    e.core.exitPrice || '',
    e.core.positionSizeUSD,
    e.realizedPnL || 0,
    e.realizedPnL ? ((e.realizedPnL / e.totalCostBasis) * 100).toFixed(2) : '',
    e.emotion || '',
    e.userNotes || '',
  ]);

  return [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');
}

/**
 * Löscht alle Daten (für Testing)
 */
export async function clearAllData() {
  await Promise.all([
    db.pendingEntries.clear(),
    db.archivedEntries.clear(),
    db.confirmedEntries.clear(),
  ]);
}
