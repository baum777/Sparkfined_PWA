/**
 * Sparkfined - Extended Journal Entry Logic
 * Auto-Capture System für Solana-Token mit erweiterten Marktdaten
 * 
 * Features:
 * - Automatische TX-Detection via Helius/Moralis Webhooks
 * - Intelligente Coin-Gruppierung (24h-Fenster)
 * - Full Exit → Sofort ins Logbuch
 * - User-konfigurierbare Extended Parameters
 * - Custom Timeframe Selection für Price Changes
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

/**
 * Core Entry Data - Immer erfasst, nicht deaktivierbar
 */
interface CoreEntryData {
  // Token Identity
  tokenAddress: string;        // Solana Mint Address
  tokenSymbol: string;          // "BONK", "JUP", "WIF"
  tokenName: string;            // "Bonk Inu", "Jupiter"
  
  // Transaction Basics
  timestamp: number;            // Unix timestamp
  txHash: string;               // Solana signature
  positionSizeUSD: number;      // $50.00
  positionSizeToken: number;    // 2,500,000 BONK
  
  // Entry/Exit Prices
  entryPrice: number;           // $0.00002
  exitPrice?: number;           // $0.000023 (if closed)
  
  // DEX Info
  dexUsed: 'Jupiter' | 'Raydium' | 'Orca' | 'Meteora' | 'Phoenix';
}

/**
 * Extended Market Data - User-toggleable in Settings
 */
interface ExtendedMarketData {
  // Market Cap & Classification
  marketCap: number;                    // $1,200,000,000
  marketCapCategory: 'Mega' | 'Large' | 'Mid' | 'Small' | 'Micro' | 'Nano';
  
  // Volume & Liquidity
  volume24h: number;                    // $85,000,000
  volumeToMcapRatio: number;            // 7.08% (Volume/MCap)
  liquidityUSD: number;                 // $45,000,000
  
  // Price Action - Dynamic Timeframes
  priceChanges: {
    [key: string]: number;              // Dynamic: "15s", "1m", "5m", "15m", "1h", "4h"
  };
  priceATH: number;                     // $0.00004
  priceDistanceFromATH: number;         // -42.5%
  
  // Token Maturity
  tokenAge: number;                     // Days since launch (540)
  tokenMaturity: 'Fresh' | 'New' | 'Established' | 'Mature';
  holderCount: number;                  // 650,000
}

/**
 * Extended Technical Data
 */
interface ExtendedTechnicalData {
  // RSI
  rsi14: number;                        // 68.2
  rsiCondition: 'Overbought' | 'Neutral' | 'Oversold';
  
  // MACD
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  macdCondition: 'Bullish' | 'Bearish' | 'Neutral';
  
  // Volume Analysis
  volumeSpike: boolean;                 // true wenn >200% avg
  volumeSpikePercent: number;           // +340% vs 20-day avg
  isPriceBreakout: boolean;             // true wenn >5% über Resistance
}

/**
 * Extended On-Chain Data (Solana)
 */
interface ExtendedOnchainData {
  // Holder Distribution
  top10HoldersPercent: number;          // 45%
  whaleConcentration: 'Critical' | 'High' | 'Medium' | 'Low';
  holderGrowth24h: number;              // +2,500
  
  // DEX Liquidity
  liquidityPools: {
    raydium?: number;
    orca?: number;
    meteora?: number;
    phoenix?: number;
  };
  
  // Transaction Metrics
  slippage: number;                     // 0.8%
  gasUsedSOL: number;                   // 0.00012
  priorityFee?: number;                 // 0.0001
  txConfirmationTime: number;           // 1.2s
}

/**
 * User Settings - Welche Extended Data werden erfasst?
 */
interface JournalDataConfig {
  // Market Data Toggles
  captureMarketCap: boolean;
  captureMarketCapCategory: boolean;
  captureVolume: boolean;
  captureVolumeToMcapRatio: boolean;
  capturePriceChanges: boolean;
  customPriceChangeTimeframes: string[];  // ["15s", "1m", "5m", "1h", "4h"]
  capturePriceATH: boolean;
  captureTokenAge: boolean;
  captureTokenMaturity: boolean;
  captureHolderCount: boolean;
  
  // Technical Data Toggles
  captureRSI: boolean;
  captureMacd: boolean;
  captureVolumeSpike: boolean;
  captureBreakout: boolean;
  
  // On-Chain Data Toggles
  captureHolderDistribution: boolean;
  captureWhaleConcentration: boolean;
  captureLiquidityPools: boolean;
  captureTxMetrics: boolean;
}

/**
 * Complete Journal Entry
 */
interface JournalEntry {
  id: string;
  
  // Core Data
  core: CoreEntryData;
  
  // Transaction History
  transactions: {
    type: 'BUY' | 'SELL';
    timestamp: number;
    amountUSD: number;
    amountToken: number;
    price: number;
    hash: string;
  }[];
  
  // Extended Data (nullable based on config)
  marketData?: ExtendedMarketData;
  technicalData?: ExtendedTechnicalData;
  onchainData?: ExtendedOnchainData;
  
  // User Enrichment
  userNotes?: string;
  emotion?: 'FOMO' | 'Setup' | 'Revenge' | 'Fear' | 'Greed';
  tags?: string[];
  voiceNoteBase64?: string;
  screenshots?: string[];  // Base64 images
  
  // Status & Lifecycle
  status: 'pending' | 'closed' | 'archived';
  createdAt: number;
  expiresAt: number;        // createdAt + 24h
  closedAt?: number;
  archivedAt?: number;
  
  // PnL Tracking
  unrealizedPnL?: number;
  realizedPnL?: number;
  totalCostBasis: number;
  avgEntryPrice: number;
}

/**
 * Pending Entry - Aktiver 24h-Eintrag
 */
interface PendingEntry extends JournalEntry {
  status: 'pending';
}

/**
 * Archived Entry - Im Logbuch
 */
interface ArchivedEntry extends JournalEntry {
  status: 'archived';
  archivedAt: number;
  archiveReason: 'full_exit' | 'expired' | 'manual';
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Klassifiziert Market Cap
 */
function getMarketCapCategory(marketCap: number): ExtendedMarketData['marketCapCategory'] {
  if (marketCap >= 10_000_000_000) return 'Mega';      // >$10B
  if (marketCap >= 1_000_000_000) return 'Large';      // $1B-10B
  if (marketCap >= 100_000_000) return 'Mid';          // $100M-1B
  if (marketCap >= 10_000_000) return 'Small';         // $10M-100M
  if (marketCap >= 1_000_000) return 'Micro';          // $1M-10M
  return 'Nano';                                       // <$1M
}

/**
 * Berechnet Token Maturity basierend auf Alter
 */
function getTokenMaturity(ageInDays: number): ExtendedMarketData['tokenMaturity'] {
  if (ageInDays < 7) return 'Fresh';           // <1 Woche
  if (ageInDays < 90) return 'New';            // <3 Monate
  if (ageInDays < 365) return 'Established';   // <1 Jahr
  return 'Mature';                              // >1 Jahr
}

/**
 * Bestimmt RSI Condition
 */
function getRSICondition(rsi: number): ExtendedTechnicalData['rsiCondition'] {
  if (rsi >= 70) return 'Overbought';
  if (rsi <= 30) return 'Oversold';
  return 'Neutral';
}

/**
 * Bestimmt MACD Condition
 */
function getMACDCondition(
  macdLine: number, 
  macdSignal: number
): ExtendedTechnicalData['macdCondition'] {
  const diff = macdLine - macdSignal;
  if (diff > 0) return 'Bullish';
  if (diff < 0) return 'Bearish';
  return 'Neutral';
}

/**
 * Klassifiziert Whale Concentration
 */
function getWhaleConcentration(
  top10Percent: number
): ExtendedOnchainData['whaleConcentration'] {
  if (top10Percent >= 75) return 'Critical';   // >75% Red Flag
  if (top10Percent >= 60) return 'High';       // 60-75%
  if (top10Percent >= 40) return 'Medium';     // 40-60%
  return 'Low';                                // <40%
}

/**
 * Berechnet PnL für Entry
 */
function calculatePnL(entry: JournalEntry): {
  unrealized: number;
  realized: number;
  total: number;
} {
  const buys = entry.transactions.filter(tx => tx.type === 'BUY');
  const sells = entry.transactions.filter(tx => tx.type === 'SELL');
  
  const totalBought = buys.reduce((sum, tx) => sum + tx.amountUSD, 0);
  const totalSold = sells.reduce((sum, tx) => sum + tx.amountUSD, 0);
  
  const totalBoughtTokens = buys.reduce((sum, tx) => sum + tx.amountToken, 0);
  const totalSoldTokens = sells.reduce((sum, tx) => sum + tx.amountToken, 0);
  
  const remainingTokens = totalBoughtTokens - totalSoldTokens;
  const avgBuyPrice = totalBought / totalBoughtTokens;
  
  const realized = totalSold - (totalSoldTokens * avgBuyPrice);
  const unrealized = remainingTokens > 0 
    ? (entry.core.exitPrice || entry.core.entryPrice) * remainingTokens - (remainingTokens * avgBuyPrice)
    : 0;
  
  return {
    unrealized,
    realized,
    total: realized + unrealized
  };
}

// ============================================================================
// MARKET DATA FETCHING
// ============================================================================

/**
 * Holt Extended Market Data von APIs
 */
async function fetchExtendedMarketData(
  tokenAddress: string,
  config: JournalDataConfig
): Promise<Partial<ExtendedMarketData>> {
  const data: Partial<ExtendedMarketData> = {};
  
  // Birdeye API für Solana Token Daten
  const birdeyeUrl = `https://public-api.birdeye.so/public/token/${tokenAddress}`;
  const birdeyeResponse = await fetch(birdeyeUrl, {
    headers: { 'X-API-KEY': process.env.BIRDEYE_API_KEY! }
  });
  const birdeyeData = await birdeyeResponse.json();
  
  // Market Cap
  if (config.captureMarketCap) {
    data.marketCap = birdeyeData.data.mc;
  }
  
  if (config.captureMarketCapCategory && data.marketCap) {
    data.marketCapCategory = getMarketCapCategory(data.marketCap);
  }
  
  // Volume
  if (config.captureVolume) {
    data.volume24h = birdeyeData.data.v24h;
  }
  
  if (config.captureVolumeToMcapRatio && data.volume24h && data.marketCap) {
    data.volumeToMcapRatio = (data.volume24h / data.marketCap) * 100;
  }
  
  // Price Changes - Custom Timeframes
  if (config.capturePriceChanges) {
    data.priceChanges = {};
    
    // User-definierte Timeframes
    for (const timeframe of config.customPriceChangeTimeframes) {
      const priceHistory = await fetchPriceHistory(tokenAddress, timeframe);
      data.priceChanges[timeframe] = priceHistory.changePercent;
    }
  }
  
  // ATH Distance
  if (config.capturePriceATH) {
    data.priceATH = birdeyeData.data.ath;
    data.priceDistanceFromATH = 
      ((birdeyeData.data.price - birdeyeData.data.ath) / birdeyeData.data.ath) * 100;
  }
  
  // Token Age
  if (config.captureTokenAge) {
    const launchTimestamp = birdeyeData.data.createdAt;
    const ageMs = Date.now() - launchTimestamp;
    data.tokenAge = Math.floor(ageMs / (1000 * 60 * 60 * 24));
  }
  
  if (config.captureTokenMaturity && data.tokenAge) {
    data.tokenMaturity = getTokenMaturity(data.tokenAge);
  }
  
  // Holder Count
  if (config.captureHolderCount) {
    data.holderCount = birdeyeData.data.holder;
  }
  
  return data;
}

/**
 * Holt Technical Indicator Data
 */
async function fetchTechnicalData(
  tokenAddress: string,
  config: JournalDataConfig
): Promise<Partial<ExtendedTechnicalData>> {
  const data: Partial<ExtendedTechnicalData> = {};
  
  // TradingView-ähnliche API für Indikatoren
  const indicatorsUrl = `https://api.example.com/indicators/${tokenAddress}`;
  const response = await fetch(indicatorsUrl);
  const indicators = await response.json();
  
  // RSI
  if (config.captureRSI) {
    data.rsi14 = indicators.rsi14;
    data.rsiCondition = getRSICondition(indicators.rsi14);
  }
  
  // MACD
  if (config.captureMacd) {
    data.macdLine = indicators.macd.line;
    data.macdSignal = indicators.macd.signal;
    data.macdHistogram = indicators.macd.histogram;
    data.macdCondition = getMACDCondition(
      indicators.macd.line,
      indicators.macd.signal
    );
  }
  
  // Volume Spike
  if (config.captureVolumeSpike) {
    const avgVolume20d = indicators.volumeAvg20d;
    const currentVolume = indicators.volume24h;
    data.volumeSpikePercent = 
      ((currentVolume - avgVolume20d) / avgVolume20d) * 100;
    data.volumeSpike = data.volumeSpikePercent > 200;
  }
  
  // Breakout Detection
  if (config.captureBreakout) {
    const resistance = indicators.resistanceLevel;
    const currentPrice = indicators.price;
    const breakoutThreshold = resistance * 1.05; // +5%
    data.isPriceBreakout = currentPrice > breakoutThreshold;
  }
  
  return data;
}

/**
 * Holt On-Chain Data (Solana)
 */
async function fetchOnchainData(
  tokenAddress: string,
  config: JournalDataConfig
): Promise<Partial<ExtendedOnchainData>> {
  const data: Partial<ExtendedOnchainData> = {};
  
  // Helius API für Solana On-Chain Daten
  const heliusUrl = `https://api.helius.xyz/v0/token-metadata?api-key=${process.env.HELIUS_API_KEY}`;
  const response = await fetch(heliusUrl, {
    method: 'POST',
    body: JSON.stringify({ mintAccounts: [tokenAddress] })
  });
  const onchainInfo = await response.json();
  
  // Holder Distribution
  if (config.captureHolderDistribution) {
    const holderData = await fetchHolderDistribution(tokenAddress);
    data.top10HoldersPercent = holderData.top10Percent;
  }
  
  if (config.captureWhaleConcentration && data.top10HoldersPercent) {
    data.whaleConcentration = getWhaleConcentration(data.top10HoldersPercent);
  }
  
  // Liquidity Pools
  if (config.captureLiquidityPools) {
    const poolData = await fetchLiquidityPools(tokenAddress);
    data.liquidityPools = poolData;
  }
  
  return data;
}

/**
 * Helper: Price History für Custom Timeframe
 */
async function fetchPriceHistory(
  tokenAddress: string,
  timeframe: string
): Promise<{ changePercent: number }> {
  // Timeframe zu Sekunden
  const timeframeMap: Record<string, number> = {
    '15s': 15,
    '30s': 30,
    '1m': 60,
    '5m': 300,
    '15m': 900,
    '1h': 3600,
    '4h': 14400,
  };
  
  const seconds = timeframeMap[timeframe] || 3600;
  const startTime = Date.now() - (seconds * 1000);
  
  const url = `https://public-api.birdeye.so/public/price_history/${tokenAddress}?from=${startTime}`;
  const response = await fetch(url, {
    headers: { 'X-API-KEY': process.env.BIRDEYE_API_KEY! }
  });
  const data = await response.json();
  
  const priceNow = data.data.items[0]?.value || 0;
  const priceThen = data.data.items[data.data.items.length - 1]?.value || 0;
  
  return {
    changePercent: ((priceNow - priceThen) / priceThen) * 100
  };
}

/**
 * Helper: Holder Distribution
 */
async function fetchHolderDistribution(tokenAddress: string) {
  const url = `https://api.helius.xyz/v0/addresses/${tokenAddress}/holders`;
  const response = await fetch(url);
  const data = await response.json();
  
  const totalSupply = data.totalSupply;
  const top10Holdings = data.holders
    .slice(0, 10)
    .reduce((sum: number, h: any) => sum + h.balance, 0);
  
  return {
    top10Percent: (top10Holdings / totalSupply) * 100
  };
}

/**
 * Helper: Liquidity Pools
 */
async function fetchLiquidityPools(tokenAddress: string) {
  const url = `https://api.birdeye.so/public/liquidity/${tokenAddress}`;
  const response = await fetch(url);
  const data = await response.json();
  
  return {
    raydium: data.pools.raydium?.liquidityUSD || 0,
    orca: data.pools.orca?.liquidityUSD || 0,
    meteora: data.pools.meteora?.liquidityUSD || 0,
    phoenix: data.pools.phoenix?.liquidityUSD || 0,
  };
}

// ============================================================================
// MAIN ENTRY LOGIC
// ============================================================================

/**
 * Erstellt oder updated Entry basierend auf neuer TX
 */
async function handleNewTransaction(
  tx: SolanaTransaction,
  userConfig: JournalDataConfig
): Promise<void> {
  // 1. Check: Existiert bereits ein Pending Entry für diesen Token?
  const existingEntry = await findActivePendingEntry(tx.tokenMint);
  
  if (existingEntry) {
    // APPEND TX zum bestehenden Entry
    await appendTransactionToEntry(existingEntry.id, tx, userConfig);
    
    // Check: Full Exit?
    const isFullExit = await checkIfFullExit(existingEntry.id);
    
    if (isFullExit) {
      // ✅ Sofort ins Logbuch archivieren
      await archiveEntry(existingEntry.id, 'full_exit');
      
      // Notification
      await showEntryClosedNotification(existingEntry);
    }
  } else {
    // CREATE neuer Pending Entry
    await createNewPendingEntry(tx, userConfig);
  }
}

/**
 * Findet aktiven Pending Entry für Token
 */
async function findActivePendingEntry(
  tokenAddress: string
): Promise<PendingEntry | null> {
  // Dexie Query (IndexedDB)
  const entry = await db.pendingEntries
    .where('core.tokenAddress')
    .equals(tokenAddress)
    .and(entry => {
      const now = Date.now();
      return entry.status === 'pending' && entry.expiresAt > now;
    })
    .first();
  
  return entry || null;
}

/**
 * Erstellt neuen Pending Entry
 */
async function createNewPendingEntry(
  tx: SolanaTransaction,
  config: JournalDataConfig
): Promise<string> {
  const tokenAddress = tx.tokenMint;
  
  // Core Data aus TX
  const coreData: CoreEntryData = {
    tokenAddress,
    tokenSymbol: tx.tokenSymbol,
    tokenName: tx.tokenName,
    timestamp: tx.blockTime * 1000,
    txHash: tx.signature,
    positionSizeUSD: tx.amountUSD,
    positionSizeToken: tx.amountToken,
    entryPrice: tx.price,
    dexUsed: tx.dex as CoreEntryData['dexUsed']
  };
  
  // Extended Data fetchen (parallel)
  const [marketData, technicalData, onchainData] = await Promise.all([
    fetchExtendedMarketData(tokenAddress, config),
    fetchTechnicalData(tokenAddress, config),
    fetchOnchainData(tokenAddress, config)
  ]);
  
  // Entry zusammenbauen
  const entry: PendingEntry = {
    id: generateId(),
    core: coreData,
    transactions: [{
      type: tx.type,
      timestamp: tx.blockTime * 1000,
      amountUSD: tx.amountUSD,
      amountToken: tx.amountToken,
      price: tx.price,
      hash: tx.signature
    }],
    marketData: Object.keys(marketData).length > 0 ? marketData as ExtendedMarketData : undefined,
    technicalData: Object.keys(technicalData).length > 0 ? technicalData as ExtendedTechnicalData : undefined,
    onchainData: Object.keys(onchainData).length > 0 ? onchainData as ExtendedOnchainData : undefined,
    status: 'pending',
    createdAt: Date.now(),
    expiresAt: Date.now() + (24 * 60 * 60 * 1000), // +24h
    totalCostBasis: tx.amountUSD,
    avgEntryPrice: tx.price
  };
  
  // In DB speichern
  await db.pendingEntries.add(entry);
  
  return entry.id;
}

/**
 * Hängt neue TX an bestehenden Entry an
 */
async function appendTransactionToEntry(
  entryId: string,
  tx: SolanaTransaction,
  config: JournalDataConfig
): Promise<void> {
  const entry = await db.pendingEntries.get(entryId);
  if (!entry) return;
  
  // Neue TX hinzufügen
  entry.transactions.push({
    type: tx.type,
    timestamp: tx.blockTime * 1000,
    amountUSD: tx.amountUSD,
    amountToken: tx.amountToken,
    price: tx.price,
    hash: tx.signature
  });
  
  // Exit Price updaten (wenn SELL)
  if (tx.type === 'SELL') {
    entry.core.exitPrice = tx.price;
  }
  
  // PnL neu berechnen
  const pnl = calculatePnL(entry);
  entry.unrealizedPnL = pnl.unrealized;
  entry.realizedPnL = pnl.realized;
  
  // Extended Data refreshen (nur wenn aktiviert)
  if (config.capturePriceChanges) {
    const marketData = await fetchExtendedMarketData(entry.core.tokenAddress, config);
    entry.marketData = { ...entry.marketData, ...marketData };
  }
  
  if (config.captureRSI || config.captureMacd) {
    const technicalData = await fetchTechnicalData(entry.core.tokenAddress, config);
    entry.technicalData = { ...entry.technicalData, ...technicalData };
  }
  
  // Update in DB
  await db.pendingEntries.put(entry);
}

/**
 * Prüft ob Position vollständig geschlossen wurde
 */
async function checkIfFullExit(entryId: string): Promise<boolean> {
  const entry = await db.pendingEntries.get(entryId);
  if (!entry) return false;
  
  const buys = entry.transactions.filter(tx => tx.type === 'BUY');
  const sells = entry.transactions.filter(tx => tx.type === 'SELL');
  
  const totalBought = buys.reduce((sum, tx) => sum + tx.amountToken, 0);
  const totalSold = sells.reduce((sum, tx) => sum + tx.amountToken, 0);
  
  // Full Exit wenn verkauft >= gekauft (mit 0.1% Toleranz für Rounding)
  return totalSold >= totalBought * 0.999;
}

/**
 * Archiviert Entry ins Logbuch
 */
async function archiveEntry(
  entryId: string,
  reason: 'full_exit' | 'expired' | 'manual'
): Promise<void> {
  const entry = await db.pendingEntries.get(entryId);
  if (!entry) return;
  
  // Final PnL berechnen
  const pnl = calculatePnL(entry);
  
  // Als Archived Entry speichern
  const archivedEntry: ArchivedEntry = {
    ...entry,
    status: 'archived',
    archivedAt: Date.now(),
    archiveReason: reason,
    closedAt: Date.now(),
    realizedPnL: pnl.total
  };
  
  await db.archivedEntries.add(archivedEntry);
  await db.pendingEntries.delete(entryId);
}

/**
 * Zeigt Notification bei Entry-Closing
 */
async function showEntryClosedNotification(entry: PendingEntry): Promise<void> {
  const pnl = calculatePnL(entry);
  const pnlFormatted = formatCurrency(pnl.total);
  const pnlPercent = ((pnl.total / entry.totalCostBasis) * 100).toFixed(2);
  
  const isProfit = pnl.total > 0;
  
  await showToast({
    title: `${entry.core.tokenSymbol} Position Closed`,
    message: `${isProfit ? '📈' : '📉'} ${pnlFormatted} (${pnlPercent}%)`,
    duration: 10000, // 10s
    actions: [
      {
        label: '📝 Add to Journal',
        onClick: () => openQuickLog(entry.id)
      },
      {
        label: '📚 View Logbook',
        onClick: () => navigateToLogbook()
      }
    ]
  });
}

/**
 * Cron Job: Expired Entries archivieren
 */
async function archiveExpiredEntries(): Promise<void> {
  const now = Date.now();
  
  const expiredEntries = await db.pendingEntries
    .where('expiresAt')
    .below(now)
    .and(entry => entry.status === 'pending')
    .toArray();
  
  for (const entry of expiredEntries) {
    await archiveEntry(entry.id, 'expired');
  }
  
  if (expiredEntries.length > 0) {
    await showToast({
      title: `${expiredEntries.length} entries archived`,
      message: 'Expired entries moved to logbook',
      duration: 5000
    });
  }
}

// Cron: Läuft alle 1h
setInterval(archiveExpiredEntries, 60 * 60 * 1000);

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function generateId(): string {
  return `entry_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function formatCurrency(amount: number): string {
  const sign = amount >= 0 ? '+' : '';
  return `${sign}$${Math.abs(amount).toFixed(2)}`;
}

// ============================================================================
// EXPORTS
// ============================================================================

export {
  // Types
  type CoreEntryData,
  type ExtendedMarketData,
  type ExtendedTechnicalData,
  type ExtendedOnchainData,
  type JournalDataConfig,
  type JournalEntry,
  type PendingEntry,
  type ArchivedEntry,
  
  // Main Functions
  handleNewTransaction,
  createNewPendingEntry,
  appendTransactionToEntry,
  archiveEntry,
  
  // Data Fetchers
  fetchExtendedMarketData,
  fetchTechnicalData,
  fetchOnchainData,
  
  // Utils
  calculatePnL,
  getMarketCapCategory,
  getTokenMaturity,
  getRSICondition,
  getMACDCondition,
  getWhaleConcentration
};
