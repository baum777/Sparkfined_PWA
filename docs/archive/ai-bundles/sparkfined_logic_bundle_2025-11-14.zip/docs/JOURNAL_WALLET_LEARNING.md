# Sparkfined TA-PWA – Journal, Wallet & Learning Layer

This document ties together:

- Trade journal structure
- Wallet auto-logging (Solana RPC / Helius)
- Quick-Log mode
- Learning Dashboard, tips & gamification

## Trade Journal (`TradeEntry`)

Core fields:

- `id: string`
- `symbol: string`
- `side: 'long' | 'short' | 'neutral'`
- `bias: BiasLabel`
- `entry_zone: string`
- `sl: string`
- `tp_levels: string[]`
- `key_levels: string[]`
- `notes_playbook: string`
- `emotion_tags?: string[]`
- `is_quick_log?: boolean`
- `created_at: string` (ISO)

Filters:

- Bias (bullish / neutral / bearish)
- Setup type (e.g. breakout, pullback – implied via notes/tags)
- Emotion (FOMO, revenge, etc.)
- Volatility buckets (derived from market data).

## Quick-Log Mode

Problem: Meme-token trades leave little time for manual journaling.

Concept:

- Minimal input:
  - Pair / Symbol
  - Price
  - Emotion (text or preset)
  - Side (long/short)
- Voice input support:
  - e.g. "Log $SOL short at 195" via Web Speech API.
- Implementation hooks:
  - On Quick-Log submit → create `TradeEntry` with `is_quick_log = true`.
  - Event: `journal_quick_log_create`.

## Wallet Auto-Logging

Goal: Automatic capture of trades via wallet address.

Entity:

- `WalletTransactionLog`:
  - `tx_id`, `wallet`, `token`, `amount`, `price?`, `side`, `ts`
  - `linked_entry_id?`
  - `auto_generated: boolean`

Flow:

1. User enables auto-log with wallet address.
2. Background sync (Solana RPC / Helius) pulls transactions.
3. For each trade:
   - Create `WalletTransactionLog`.
   - Optionally generate a draft `TradeEntry` (linkable via "Reflect" button).

Events:

- `wallet_autolog_enabled`
- `wallet_autolog_sync_run`
- `journal_reflect_open`
- `journal_reflect_save`

## Learning Dashboard & Tips

Purpose:

- Turn raw logs + reflections into patterns and insights:
  - e.g. "70% wins at low volatility", "80% FOMO-trades lose".

Data structures:

- `LearningMetric` – single metric (e.g. win-rate for a segment).
- `PersonalizedTip` – AI-generated guidance with provenance:
  - `tip_id`, `tip_text`, `reason`, `derived_from_entry_ids[]`.
- `GamificationState`:
  - `reflection_streak_days`
  - `skill_streak_days`
  - `badges[]`

Key flows:

- Learning Dashboard:
  - Aggregates metrics per volatility, emotion, time-of-day, etc.
- Personalized Tips:
  - Weekly reflection prompts.
  - Actionable suggestions (e.g. "Wait for volume confirmation").
- Events:
  - `learning_dashboard_open`
  - `learning_insight_view`
  - `learning_tip_shown`
  - `learning_tip_clicked`
  - `streak_progress_update`
  - `badge_earned`

## Mobile & Desktop UX

Mobile:

- Journal as bottom sheet.
- Swipe between sections (Entry, Levels, Flow, Learning).
- Voice prompts usable in Quick-Log and Reflection.

Desktop:

- Floating window:
  - Draggable, dockable at screen edges.
  - Transparency toggle on inactivity.
  - Hotkeys (e.g. Alt+M, Alt+L) for multitasking.

Export & Sharing:

- Meme/Share cards:
  - Preformatted, X-ready images.
- Events:
  - Uses `ui_export_start` + higher-level share actions in the app.
