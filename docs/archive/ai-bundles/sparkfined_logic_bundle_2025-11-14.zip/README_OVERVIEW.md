# Sparkfined TA-PWA – Logic & Structure Bundle

This bundle collects the **core logic structures** for:

- AI & model orchestration
- Heuristic / layered technical analysis
- Advanced insight card & token-gated access
- Journal, wallet logging & learning layer
- Full event catalog for UI, AI and telemetry

All content is distilled from:
- the `sparkfined_ai_patch` files (API routes, orchestrator, clients, botScore, sanity, AB plan),
- plus your extended specs (layered analysis model, journal, replay, wallet auto-logging, mobile/desktop UX, etc.).

Use these files as a **single source of truth** for typing, event wiring and further design docs.
