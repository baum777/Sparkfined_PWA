// Sparkfined TA-PWA – Event Catalog Types
// Structural reference for UI, AI, telemetry & token-lock events.

export type AppEventId =
  // AI / orchestrator / token-lock
  | 'ui.market_snapshot.requested'
  | 'ui.trade_plan.requested'
  | 'ui.journal.condense_requested'
  | 'ui.social_analysis.requested'
  | 'ai.orchestrator.market_analysis.started'
  | 'ai.orchestrator.market_analysis.completed'
  | 'ai.orchestrator.social_analysis.completed'
  | 'ai.model.grok.called'
  | 'ai.model.grok.succeeded'
  | 'ai.model.grok.failed'
  | 'ai.model.openai.called'
  | 'ai.model.openai.succeeded'
  | 'ai.model.openai.failed'
  | 'ai.sanity_check.applied'
  | 'ai.bot_score.computed'
  | 'ai.sampling.decision'
  | 'tokenlock.feature_access_attempt'
  | 'tokenlock.feature_access_result'
  | 'abtest.bucket.assigned'
  | 'abtest.sample.labelled'
  | 'journal.entry.enriched.social'
  | 'journal.entry.enriched.trade_plan'
  // Advanced insight / overrides
  | 'ui.advanced_insight.opened'
  | 'ui.advanced_insight.field_overridden'
  | 'ui.advanced_insight.saved'
  // Watchlist & search
  | 'watchlist_add'
  | 'watchlist_row_select'
  | 'watchlist_bulk_remove'
  | 'watchlist_open_chart'
  | 'watchlist_remove'
  | 'watchlist_sort_change'
  | 'ui_search_select'
  // Dashboard, signals, journal, toasts
  | 'dash_symbol_open'
  | 'ui_snapshot_open'
  | 'ui_snapshot_create'
  | 'dash_signal_open'
  | 'dash_journal_open'
  | 'ui_toast_dismiss'
  // Replay / session
  | 'replay_session_load'
  | 'replay_play_toggle'
  | 'replay_speed_change'
  | 'replay_seek'
  | 'replay_bookmark_create'
  | 'replay_step'
  | 'replay_export_start'
  // Chart & drawing
  | 'chart_crosshair_move'
  | 'chart_click'
  | 'chart_tool_activate'
  | 'chart_annotation_create'
  | 'chart_indicator_add'
  | 'chart_indicator_toggle'
  // Orders, alerts, layout, export
  | 'ui_trade_quick_open'
  | 'order_place_preview'
  | 'order_panel_open'
  | 'order_place_sim'
  | 'alert_create'
  | 'ui_layout_save'
  | 'ui_export_start'
  // Learning & tips / wallet / gamification / screenshot
  | 'journal_quick_log_create'
  | 'wallet_autolog_enabled'
  | 'wallet_autolog_sync_run'
  | 'journal_reflect_open'
  | 'journal_reflect_save'
  | 'learning_dashboard_open'
  | 'learning_insight_view'
  | 'learning_tip_shown'
  | 'learning_tip_clicked'
  | 'streak_progress_update'
  | 'badge_earned'
  | 'screenshot_upload_start'
  | 'screenshot_upload_done'
  | 'screenshot_crop_done'
  | 'screenshot_ocr_success'
  | 'screenshot_ocr_failed'
  | 'ca_resolve_success'
  | 'ca_resolve_failed';

export interface EventPayloadMap {
  // --- AI / orchestrator / token-lock ---

  'ui.market_snapshot.requested': {
    symbol: string;
    timeframe: string;
    requested_mode: 'basic' | 'advanced';
  };

  'ui.trade_plan.requested': {
    symbol: string;
    timeframe: string;
    context?: string;
  };

  'ui.journal.condense_requested': {
    journalId: string;
    bodyLength: number;
  };

  'ui.social_analysis.requested': {
    symbol: string;
    query?: string;
    postCount: number;
  };

  'ai.orchestrator.market_analysis.started': {
    request_id: string;
    symbol: string;
    timeframe: string;
  };

  'ai.orchestrator.market_analysis.completed': {
    request_id: string;
    symbol: string;
    hasSnapshot: boolean;
    hasDeepSignal: boolean;
    hasAdvanced: boolean;
  };

  'ai.orchestrator.social_analysis.completed': {
    request_id: string;
    symbol: string;
    postCount: number;
    sentiment: string;
    confidence: number;
  };

  'ai.model.grok.called': {
    request_id: string;
    task: string;
    symbol?: string;
    payloadSize?: number;
  };

  'ai.model.grok.succeeded': {
    request_id: string;
    task: string;
    duration_ms: number;
    tokens?: number;
    cost?: number;
  };

  'ai.model.grok.failed': {
    request_id: string;
    task: string;
    error: string;
    status?: number;
  };

  'ai.model.openai.called': {
    request_id: string;
    task: string;
    symbol?: string;
    payloadSize?: number;
  };

  'ai.model.openai.succeeded': {
    request_id: string;
    task: string;
    duration_ms: number;
    tokens?: number;
    cost?: number;
  };

  'ai.model.openai.failed': {
    request_id: string;
    task: string;
    error: string;
    status?: number;
  };

  'ai.sanity_check.applied': {
    request_id: string;
    anomalies?: string[];
  };

  'ai.bot_score.computed': {
    post_id: string;
    bot_score: number;
    features_sample?: Record<string, unknown>;
  };

  'ai.sampling.decision': {
    event: string;
    rate: number;
    sampled: boolean;
    user_id?: string;
    ab_bucket?: string;
  };

  'tokenlock.feature_access_attempt': {
    user_id?: string;
    feature: string;
    tier_required: string;
    has_lock: boolean;
    token_lock_id?: string;
  };

  'tokenlock.feature_access_result': {
    user_id?: string;
    feature: string;
    is_unlocked: boolean;
    reason?: string;
  };

  'abtest.bucket.assigned': {
    user_id?: string;
    experiment: string;
    bucket: string;
  };

  'abtest.sample.labelled': {
    request_id: string;
    labeler_id?: string;
    ground_truth: unknown;
  };

  'journal.entry.enriched.social': {
    journal_id: string;
    social_sentiment: string;
    social_confidence: number;
  };

  'journal.entry.enriched.trade_plan': {
    journal_id: string;
    signalStrength?: string;
    entriesCount: number;
  };

  // --- Advanced insight ---

  'ui.advanced_insight.opened': {
    user_id?: string;
    symbol: string;
    timeframe: string;
    access: {
      feature: string;
      tier: string;
      is_unlocked: boolean;
    };
  };

  'ui.advanced_insight.field_overridden': {
    user_id?: string;
    symbol: string;
    field_path: string;
    auto_value: unknown;
    user_value: unknown;
  };

  'ui.advanced_insight.saved': {
    user_id?: string;
    symbol: string;
    timeframe: string;
    overrides_count: number;
    journal_id?: string;
  };

  // --- Watchlist & search ---

  'watchlist_add': {
    symbol: string;
    source: 'search' | 'signal';
  };

  'watchlist_row_select': {
    symbol: string;
    selected: boolean;
  };

  'watchlist_bulk_remove': {
    symbols: string[];
  };

  'watchlist_open_chart': {
    symbol: string;
  };

  'watchlist_remove': {
    symbol: string;
  };

  'watchlist_sort_change': {
    sortBy: string;
    direction?: 'asc' | 'desc';
  };

  'ui_search_select': {
    query: string;
    selectedSymbol: string;
  };

  // --- Dashboard, signals, journal, toasts ---

  'dash_symbol_open': {
    symbol: string;
  };

  'ui_snapshot_open': {
    context: 'dashboard' | 'chart';
    symbol?: string;
  };

  'ui_snapshot_create': {
    snapId: string;
    symbol: string;
    ts: string;
  };

  'dash_signal_open': {
    signalId: string;
  };

  'dash_journal_open': {
    from: 'dashboard' | 'chart' | 'replay';
  };

  'ui_toast_dismiss': {
    toastId: string;
  };

  // --- Replay / session ---

  'replay_session_load': {
    sessionId: string;
  };

  'replay_play_toggle': {
    sessionId: string;
    playing: boolean;
  };

  'replay_speed_change': {
    sessionId: string;
    speed: number;
  };

  'replay_seek': {
    sessionId: string;
    ts: number;
  };

  'replay_bookmark_create': {
    sessionId: string;
    ts: number;
    note?: string;
  };

  'replay_step': {
    sessionId: string;
    direction: 'fwd' | 'back';
    amount: number;
  };

  'replay_export_start': {
    sessionId: string;
    from: number;
    to: number;
  };

  // --- Chart & drawing ---

  'chart_crosshair_move': {
    symbol: string;
    timeframe: string;
    x: number;
    y: number;
    ts: number;
    price: number;
  };

  'chart_click': {
    symbol: string;
    timeframe: string;
    action: 'place_marker' | string;
    coords: { x: number; y: number };
  };

  'chart_tool_activate': {
    tool: 'trendline' | 'fib' | 'rect' | string;
    symbol?: string;
  };

  'chart_annotation_create': {
    id: string;
    symbol: string;
    coords: { x: number; y: number };
    text: string;
  };

  'chart_indicator_add': {
    symbol: string;
    indicator: string;
    params: Record<string, unknown>;
  };

  'chart_indicator_toggle': {
    symbol: string;
    indicator: string;
    visible: boolean;
  };

  // --- Orders, alerts, layout, export ---

  'ui_trade_quick_open': {
    symbol: string;
    source: 'watchlist_row' | 'dashboard_row';
  };

  'order_place_preview': {
    symbol: string;
    side: 'buy' | 'sell';
    size: number;
    price?: number;
    sl?: number;
    tp?: number;
  };

  'order_panel_open': {
    symbol: string;
  };

  'order_place_sim': {
    symbol: string;
    side: 'buy' | 'sell';
    size: number;
    sl?: number;
    tp?: number;
  };

  'alert_create': {
    symbol: string;
    condition: string;
    value: number;
    direction: 'above' | 'below';
  };

  'ui_layout_save': {
    layoutId: string;
    panelsCount?: number;
    symbol?: string;
  };

  'ui_export_start': {
    format: 'png' | 'pdf' | 'json';
    options: Record<string, unknown>;
  };

  // --- Learning, wallet, tips, gamification, screenshot ---

  'journal_quick_log_create': {
    entryId: string;
    symbol: string;
    side: 'long' | 'short' | 'neutral';
    emotion?: string;
  };

  'wallet_autolog_enabled': {
    wallet: string;
    enabled: boolean;
  };

  'wallet_autolog_sync_run': {
    wallet: string;
    txCount: number;
    status: 'ok' | 'error';
  };

  'journal_reflect_open': {
    entryId: string;
  };

  'journal_reflect_save': {
    entryId: string;
    emotion_tags?: string[];
  };

  'learning_dashboard_open': {
    from: 'dashboard' | 'journal';
  };

  'learning_insight_view': {
    insightId: string;
  };

  'learning_tip_shown': {
    tip_id: string;
  };

  'learning_tip_clicked': {
    tip_id: string;
  };

  'streak_progress_update': {
    reflection_streak_days: number;
    skill_streak_days: number;
  };

  'badge_earned': {
    badgeId: string;
  };

  'screenshot_upload_start': {
    screenshot_id: string;
  };

  'screenshot_upload_done': {
    screenshot_id: string;
    file_size_bytes: number;
  };

  'screenshot_crop_done': {
    screenshot_id: string;
  };

  'screenshot_ocr_success': {
    screenshot_id: string;
    token_symbol?: string;
    price?: number;
  };

  'screenshot_ocr_failed': {
    screenshot_id: string;
    error: string;
  };

  'ca_resolve_success': {
    ca: string;
    token_symbol?: string;
  };

  'ca_resolve_failed': {
    ca: string;
    error: string;
  };
}

// Generic helper type
export type AppEventPayload<E extends AppEventId> = EventPayloadMap[E];
