
export function computeScore(n: {
  clarity: number;
  discipline: number;
  patternStrength: number;
  conviction: number;
  emotionalVolatility: number;
}) {
  const W1=0.30, W2=0.25, W3=0.20, W4=0.15, W5=0.40;
  return (
    n.clarity*W1 +
    n.discipline*W2 +
    n.patternStrength*W3 +
    n.conviction*W4 -
    n.emotionalVolatility*W5
  ) * 100;
}
