
export function normalizeEmotion(intensity: number): number {
  return 1 / (1 + Math.exp(-(intensity - 5)));
}

export function normalizeLinear(v: number): number {
  return Math.min(1, Math.max(0, v / 10));
}
