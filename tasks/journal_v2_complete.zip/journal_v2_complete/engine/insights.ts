
export function generateInsights(archetype: string, bias: string[], d: any) {
  const out: string[] = [];

  if (archetype === "The Overthinker")
    out.push("You are overanalyzing low-signal noise. Simplify your thesis.");

  if (bias.includes("fear-of-loss"))
    out.push("Fear is distorting your clarity. Reduce size or pause before acting.");

  if (bias.includes("overconfidence"))
    out.push("Your conviction is inflated; validate your thesis objectively.");

  if (d.emotionalVolatility > 0.5)
    out.push("Emotional and rational layers diverge — reduce exposure.");

  return out;
}
