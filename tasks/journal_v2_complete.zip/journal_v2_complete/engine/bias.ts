
import { JournalRawInput } from "../types/input";
import { JournalNormalized } from "../types/normalized";

export function detectBias(input: JournalRawInput, n: JournalNormalized) {
  const flags: string[] = [];

  if (input.emotionalState === "fear" && input.emotionIntensity > 7)
    flags.push("fear-of-loss");

  if (n.conviction > 0.8 && n.clarity < 0.5)
    flags.push("overconfidence");

  if (/recover|make back|fix the loss/i.test(input.reasoning))
    flags.push("revenge-trading");

  if (/I think|it will/i.test(input.expectation))
    flags.push("confirmation-bias");

  return flags;
}
