
import { JournalNormalized } from "../types/normalized";
import { JournalDerived } from "../types/derived";

export function inferArchetype(
  n: JournalNormalized,
  d: JournalDerived,
  bias: string[]
) {
  if (n.clarity < 0.4 && n.conviction < 0.4 && d.emotionalVolatility > 0.5)
    return "The Overthinker";

  if (n.conviction > 0.7 && n.discipline < 0.3)
    return "The Gambler";

  if (bias.includes("fear-of-loss"))
    return "The Shadow Degen";

  if (n.clarity > 0.7 && n.discipline > 0.7)
    return "The Warrior";

  return "The Seeker";
}
