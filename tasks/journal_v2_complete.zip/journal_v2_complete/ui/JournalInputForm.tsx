
import React, { useState } from "react";
import { JournalRawInput } from "../types/input";

export function JournalInputForm({ onSubmit }: { onSubmit: (d: JournalRawInput)=>void }) {
  const [emotionalState,setEmotionalState]=useState("calm");
  const [emotionIntensity,setEmotionIntensity]=useState(5);
  const [conviction,setConviction]=useState(5);
  const [patternQuality,setPatternQuality]=useState(5);
  const [marketContext,setMarketContext]=useState("chop");
  const [reasoning,setReasoning]=useState("");
  const [expectation,setExpectation]=useState("");
  const [selfReflection,setSelfReflection]=useState("");

  return (
    <div>
      <h2>Journal Entry</h2>
      <label>Emotion</label>
      <select value={emotionalState} onChange={e=>setEmotionalState(e.target.value)}>
        <option>fear</option><option>greed</option><option>calm</option>
      </select>

      <label>Emotion Intensity</label>
      <input type="range" min={0} max={10} value={emotionIntensity} onChange={e=>setEmotionIntensity(+e.target.value)}/>

      <label>Conviction</label>
      <input type="range" min={0} max={10} value={conviction} onChange={e=>setConviction(+e.target.value)}/>

      <label>Pattern Quality</label>
      <input type="range" min={0} max={10} value={patternQuality} onChange={e=>setPatternQuality(+e.target.value)}/>

      <label>Market Context</label>
      <select value={marketContext} onChange={e=>setMarketContext(e.target.value)}>
        <option>chop</option><option>breakout</option><option>high-vol</option>
      </select>

      <label>Reasoning</label>
      <textarea value={reasoning} onChange={e=>setReasoning(e.target.value)}/>

      <button onClick={()=>{
        onSubmit({
          emotionalState,
          emotionIntensity,
          conviction,
          patternQuality,
          marketContext,
          reasoning,
          expectation,
          selfReflection,
          createdAt: Date.now()
        })
      }}>Submit</button>
    </div>
  );
}
