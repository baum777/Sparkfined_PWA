
import React from "react";
import { JournalOutput } from "../types/output";

export function JournalResultView({ result }: { result: JournalOutput }) {
  return (
    <div>
      <h2>Archetype: {result.archetype}</h2>
      <p>Score: {result.score.toFixed(1)}</p>
      <h3>Insights</h3>
      <ul>{result.insights.map((i,idx)=><li key={idx}>{i}</li>)}</ul>
    </div>
  );
}
