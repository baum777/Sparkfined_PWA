
import Dexie, { Table } from "dexie";

export interface JournalDBEntry {
  id?: number;
  raw: any;
  output: any;
  createdAt: number;
  version: number;
}

export class JournalDB extends Dexie {
  journal!: Table<JournalDBEntry, number>;
  constructor(){
    super("JournalV2DB");
    this.version(1).stores({
      journal: "++id, createdAt"
    });
  }
}

export const journalDB = new JournalDB();
