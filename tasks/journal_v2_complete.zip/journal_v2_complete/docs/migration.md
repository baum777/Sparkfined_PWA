
# Journal 1.0 → 2.0 Migration Guide

## Overview
Journal 1.0 stored entries with minimal fields and no derived metrics.
Journal 2.0 introduces:
- Normalization layer
- Derived metrics
- Archetypes
- Bias detection
- Scoring engine
- Insight system
- Dexie v2 schema

## Migration Strategy
1. Read all Journal 1.0 entries from old Dexie table.
2. Transform each entry:
   - Map old emotional state → new emotionIntensity (estimate: old 0–5 mapped to 0–10).
   - conviction → same numeric scale.
   - patternQuality → default 5 if missing.
   - Market context default: "chop".
3. Run the Journal 2.0 pipeline for each migrated entry.
4. Save transformed entries into JournalV2DB.
5. Keep old DB intact for backup.

## Example Mapping
Old:
{
  "emotion": "fear",
  "conviction": 3,
  "note": "I think price will go up"
}

New:
{
  emotionalState: "fear",
  emotionIntensity: 6,
  conviction: 3,
  patternQuality: 5,
  marketContext: "chop",
  reasoning: "",
  expectation: "",
  selfReflection: "",
  createdAt: old.createdAt
}

## Script Example
import { journalDBv1 } from "./oldDB";
import { journalDB } from "./journal-v2-schema";
import { runJournalPipeline } from "../engine/pipeline";

async function migrate() {
  const old = await journalDBv1.entries.toArray();
  for(const e of old){
    const raw = {
      emotionalState: e.emotion || "calm",
      emotionIntensity: (e.emotionIntensity ?? 3) * 2,
      conviction: e.conviction ?? 5,
      patternQuality: 5,
      marketContext: "chop",
      reasoning: e.note ?? "",
      expectation: "",
      selfReflection: "",
      createdAt: e.createdAt
    };
    const output = runJournalPipeline(raw);
    await journalDB.journal.add({ raw, output, createdAt: raw.createdAt, version: 2 });
  }
}
