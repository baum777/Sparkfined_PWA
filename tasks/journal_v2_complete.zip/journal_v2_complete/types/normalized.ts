
export interface JournalNormalized {
  emotion: number;          // 0–1
  conviction: number;       // 0–1
  clarity: number;          // 0–1
  discipline: number;       // 0–1
  patternStrength: number;  // 0–1
}
