
import { JournalArchetype } from "./archetypes";
import { JournalNormalized } from "./normalized";
import { JournalDerived } from "./derived";

export interface JournalOutput {
  archetype: JournalArchetype;
  metrics: JournalDerived;
  normalized: JournalNormalized;
  insights: string[];
  recommendations: string[];
  emotionalTrend?: "rising" | "falling" | "stable";
  score: number; // 0–100
}
