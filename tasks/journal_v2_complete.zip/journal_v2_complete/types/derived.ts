
export type CognitiveBias =
  | "fear-of-loss"
  | "overconfidence"
  | "revenge-trading"
  | "confirmation-bias"
  | "fomo";

export interface JournalDerived {
  emotionalVolatility: number;   // 0–1
  riskAlignment: number;         // 0–1
  cognitiveBiasFlags: CognitiveBias[];
  decisionQuality: number;       // composite
}
