
export type JournalArchetype =
  | "The Overthinker"
  | "The Gambler"
  | "The Analyzer"
  | "The Warrior"
  | "The Seeker"
  | "The Apprentice"
  | "The Tilted"
  | "The Ice-Cold"
  | "The Shadow Degen";
