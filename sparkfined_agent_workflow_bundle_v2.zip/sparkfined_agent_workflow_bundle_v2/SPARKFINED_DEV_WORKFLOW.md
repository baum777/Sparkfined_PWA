# Sparkfined Entwicklungs-Workflow – Hardening, AI-Wiring & UI mit Agenten (aktualisiert)

Dieses Dokument beschreibt, wie du dein Sparkfined-PWA-Projekt mit
drei Branch-Linien **und** zwei Agenten-Typen (Claude 4.5 & Codex-high)
effektiv steuerst.

---

## 1. Branch-Architektur

### 1.1 AI-Wiring-Branch (Loop P0)

- Beispiel: `ai-wiring/p0-beta-v0.9`
- Fokus:
  - P0-Tasks nach dem AI-Cleanup
  - Imports auf neue AI-Typen umstellen (`@/types/ai`)
  - `computeBotScore` und `sanityCheck` in die Pipeline einhängen
- Ziel: **AI-Struktur ist nicht nur integriert, sondern aktiv genutzt.**

### 1.2 Hardening-Branch

- Beispiel: `ci-hardening/loop-6-7`
- Fokus:
  - CI-Fehler
  - Build-Probleme
  - Env-Handling
  - tiefere Refactors (z.B. Loop 6, 7)
- Ziel: **dauerhafte technische Stabilität**.

### 1.3 UI-Branch

- Beispiel: `feature/ui-phase-1`
- Fokus:
  - Pages, Komponenten, Layouts
  - UI-Hooks, View-Logik
- Ziel: **UI wächst**, ohne die Technical Baseline zu destabilisieren.

---

## 2. Source-of-Truth für AI

Nach dem Cleanup gelten folgende Dateien als maßgeblich:

- `src/types/ai.ts`  
  → Zentrale Typen für AI (Anfragen, Antworten, Heuristik-Resultate, etc.).

- `src/lib/ai/heuristics/`  
  → Funktions-Implementierungen wie `computeBotScore`, Sanity Checks, Hilfsfunktionen.

Legacy-Dateien wie `ai/types-legacy.ts` sind nur noch zur Referenz da und sollen
für neuen Code nicht mehr verwendet werden.

---

## 3. Rollen der Agenten

### 3.1 Claude 4.5 – Supervisor & Architekt

Claude bekommt:
- Logs, Loop-Beschreibungen, Kontext.
- Aufgabe: **Planen**, **Strukturieren**, **Prompts für Codex schreiben**.

Er ist zuständig für:
- Loop P0 planen (AI-Wiring)
- Hardening-Loops (6, 7, …) planen
- Branch- und Scope-Entscheidungen vorbereiten

Claude macht NICHT:
- Direkt Code schreiben.
- Branches mergen oder Tools ausführen.

### 3.2 Codex-high – Implementierer & Patch-Agent

Codex bekommt:
- Sehr konkrete Systemprompts (von dir, oft via Claude vorbereitet).
- Einen **klaren Loop** oder ein **UI-Feature**.
- Genaue Dateien, die geändert werden dürfen.

Codex liefert:
- **Unified Diffs**.
- Kurze Diagnosen.

Codex macht NICHT:
- Tools ausführen.
- Branches verwalten.

---

## 4. Loop-Logik (Hardening & AI-Wiring)

### 4.1 Loop-Status

Jeder Loop hat einen Status:
- `PLANNED`
- `IN_PROGRESS`
- `BLOCKED (reason)`
- `DONE`

Du pflegst diese Stati im Canvas oder in einer Datei (`SYSTEM_LOOPS.md`).

### 4.2 Spezieller Loop: P0 – AI-Wiring

**Ziel:**  
Die neuen AI-Typen und Heuristiken werden tatsächlich im Code verwendet.

**Typische Schritte:**
1. Imports: `from 'ai/types'` → `from '@/types/ai'`
2. `computeBotScore` in Social-Analysis-Pfade integrieren
3. `sanityCheck` in der AI-Pipeline platzieren
4. Vollständiger Check-Lauf:
   ```bash
   pnpm install
   pnpm typecheck
   pnpm lint
   pnpm test
   pnpm build
   ```

### 4.3 Allgemeiner Loop-Ablauf

1. **Analyse (Claude)**  
   - Identifiziert Blocker / nächste sinnvolle Aufgabe.
   - Ordnet sie Loop P0, 6, 7, … zu.

2. **Plan (Claude)**  
   - Zerlegt den Loop in Schritte (z.B. Imports → Heuristik-Wiring → Sanity → Tests).
   - Schreibt Systemprompt für Codex.

3. **Implementierung (Codex)**  
   - Liefert Diffs pro Step.

4. **Verifikation (du)**  
   - Nach jedem Step:
     ```bash
     pnpm lint
     pnpm typecheck
     pnpm test
     pnpm build
     ```
   - Loop erst auf `DONE` setzen, wenn alles grün ist.

---

## 5. UI-Workflow (parallel)

1. UI-Branch erstellen:
   ```bash
   git checkout -b feature/ui-phase-1 main
   ```

2. UI-Tasks definieren („Phase 1 UI“):
   - z.B. `HeaderNav`, `DashboardKpiStrip`, `JournalEntryCard`

3. Codex-UI-Agent einsetzen mit einem klaren Prompt:
   - Welche Komponenten?
   - Welche Props?
   - Welche Dateien sind tabu (z.B. `ai/**` und `scripts/**`)?

4. Regelmäßig auf den aktuellen Stand bringen:
   ```bash
   git fetch origin
   git rebase origin/main
   ```

5. Dev-Checks:
   ```bash
   pnpm lint
   pnpm typecheck
   pnpm test
   pnpm dev
   ```

---

## 6. Logische Brücken für einfache Handhabung

1. **Public Contracts**  
   - Halte zentrale Typen (z.B. `MarketKpi`, `JournalNote`, AI-Typen) in Contract-Dateien.  
   - UI-Branch nutzt diese Typen, Hardening/AI-Wiring kann intern umbauen, solange Contracts stabil bleiben.

2. **Feature-Flags**  
   - Nutze Flags wie `newDashboard` oder `journalingV2`, um neue UI im Code zu haben, aber per Flag abschaltbar zu machen.

3. **Commit-Präfixe**  
   - `LOOP-P0[AI-WIRING][CODEX]: ...`
   - `LOOP-6[HARDENING][CODEX]: ...`
   - `UI-P1[CODEX]: ...`  
   → du erkennst im `git log` sofort, welche Commits zu welchem Strang gehören.

4. **Parking Lot für Ideen**  
   - Eine Liste (`PARKING_LOT.md`), in der neue Ideen landen, die nicht zum aktuellen Loop gehören.

5. **Definition of Done pro Branch**  
   - AI-Wiring (P0): Imports & Wiring abgeschlossen, CI grün.  
   - Hardening: CI komplett grün, Loop im Canvas auf `DONE`.  
   - UI: Komponente rendert, ist typisiert, optional gibt es einen einfachen Test.

---

## 7. Zusammenfassung

- **Claude** denkt & plant (inkl. Loop P0, 6, 7 …).  
- **Codex** schreibt & patcht (für einzelne, klar definierte Loops/Features).  
- **Du** steuerst Branches, Merges, Loops und priorisierst, was wirklich in den nächsten Loop gehört.

Wenn du dich an diese Struktur hältst, kannst du:
- AI-Wiring (P0), Hardening und UI-Bau **parallel** vorantreiben,
- ohne dass sich die Ebenen gegenseitig blockieren.
