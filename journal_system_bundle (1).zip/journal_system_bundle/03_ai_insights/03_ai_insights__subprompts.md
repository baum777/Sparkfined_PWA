# SUB-PROMPTS: AI Insights Layer (Layer 03)

## SP-03-01: Pattern Detected Notification
**PROMPT:**
```
🧠 PATTERN DETECTED

**{PATTERN_NAME}**
Confidence: {CONFIDENCE}% | Occurrences: {COUNT}

{DESCRIPTION}

**Recommendation:** {SUGGESTION}

[View Related Trades →] [Helpful? 👍 👎]
```

## SP-03-02: Weekly Pattern Summary
**PROMPT:**
```
📊 WEEKLY PATTERN REPORT

Top 3 Patterns This Week:
1. {Pattern} (seen {X} times)
2. {Pattern} (seen {X} times)
3. {Pattern} (seen {X} times)

**Biggest Opportunity:**
{Insight with highest impact}

[View Full Report →]
```

## SP-03-03: Pre-Trade Warning
**PROMPT:**
```
⚠️ PRE-TRADE INSIGHT

Similar conditions to {X} past trades where you {BEHAVIOR}.
{WIN_RATE}% success rate in this scenario.

**Suggestion:** {ACTION}

[Proceed Anyway] [Journal First] [Skip Trade]
```

**STATUS**: ✅ Layer 03 Sub-Prompts Complete
