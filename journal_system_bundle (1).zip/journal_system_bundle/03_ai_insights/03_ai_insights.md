# 03 — AI INSIGHTS & PATTERN RECOGNITION LAYER

## PURPOSE

The AI Insights Layer analyzes journal entries to detect recurring patterns, generate personalized recommendations, and provide behavioral feedback that helps traders break negative cycles and reinforce positive ones.

---

## CORE CAPABILITIES

### 1. PATTERN DETECTION
- Identify recurring emotional triggers (e.g., "revenge trading after losses")
- Detect behavioral loops (e.g., "moves stops when scared")
- Cross-reference similar past trades
- Calculate pattern confidence scores

### 2. INSIGHT GENERATION
- Personalized recommendations based on historical data
- "If you feel X, you tend to do Y" observations
- Setup-specific performance analysis
- Emotion-performance correlation

### 3. PREDICTIVE WARNINGS
- "You're about to enter a trade with similar conditions to 5 past losses"
- "Your last 3 FOMO entries resulted in losses—pause and breathe"
- Pre-trade reflection prompts triggered by detected patterns

---

## DATA MODEL

```typescript
interface AIInsight {
  insightId: string;
  userId: string;
  generatedAt: timestamp;
  
  // PATTERN IDENTIFIED
  pattern: {
    type: 'emotional' | 'behavioral' | 'setup' | 'timing';
    name: string;              // e.g., "revenge_trading_loop"
    description: string;
    confidence: number;        // 0-100
    occurrences: number;
    firstSeen: timestamp;
    lastSeen: timestamp;
  };
  
  // SUPPORTING EVIDENCE
  relatedEntries: string[];    // Entry IDs that show this pattern
  
  // RECOMMENDATION
  suggestion: string;
  actionable: boolean;
  
  // USER INTERACTION
  acknowledged: boolean;
  helpful: boolean | null;     // User feedback
}
```

---

## PATTERN TAXONOMY

### Emotional Patterns
- **Revenge Trading Loop**: Loss → Frustration → Impulsive re-entry → Bigger loss
- **FOMO Cascade**: Missed move → Fear → Late entry → Loss → Regret
- **Fear Paralysis**: Setup identified → Doubt → No entry → Missed profit → Regret
- **Euphoria Trap**: Big win → Overconfidence → Oversized next trade → Loss

### Behavioral Patterns
- **Stop Movement**: Consistently moves stops when trade goes against plan
- **Early Exit**: Exits winners before target due to fear
- **Overtrading**: Enters multiple trades after losses to "get back"
- **Plan Deviation**: Documents good plan but doesn't follow it

### Setup Patterns
- **Breakout Bias**: Performs well on breakouts, poorly on reversals
- **Timeframe Mismatch**: Better on 15m than 5m (or vice versa)
- **Session Performance**: Better during Asian session vs. NY session

---

## PATTERN DETECTION ALGORITHMS

### Cross-Entry Pattern Detection

```typescript
async function detectPatterns(userId: string): Promise<AIInsight[]> {
  const entries = await getRecentEntries(userId, 30); // Last 30 entries
  const insights: AIInsight[] = [];
  
  // EMOTIONAL PATTERN: Revenge Trading
  const revengeTrades = entries.filter(e => 
    e.reflection.behaviorTags.includes('revenge_entry')
  );
  
  if (revengeTrades.length >= 3) {
    insights.push({
      pattern: {
        type: 'emotional',
        name: 'revenge_trading_loop',
        description: 'You tend to revenge trade after losses',
        confidence: Math.min(revengeTrades.length * 20, 100),
        occurrences: revengeTrades.length
      },
      relatedEntries: revengeTrades.map(e => e.entryId),
      suggestion: 'Take a 15-minute break after any loss before considering next trade',
      actionable: true
    });
  }
  
  // BEHAVIORAL PATTERN: Stop Movement
  const stopMovedTrades = entries.filter(e =>
    e.reflection.behaviorTags.includes('stop_moved')
  );
  
  if (stopMovedTrades.length >= 4) {
    insights.push({
      pattern: {
        type: 'behavioral',
        name: 'stop_movement_pattern',
        description: 'You frequently move your stop when trade goes against you',
        confidence: 90,
        occurrences: stopMovedTrades.length
      },
      relatedEntries: stopMovedTrades.map(e => e.entryId),
      suggestion: 'Set stop and write "DO NOT MOVE" on a sticky note visible while trading',
      actionable: true
    });
  }
  
  // SETUP PATTERN: Performance by Setup Type
  const setupPerformance = analyzeSetupPerformance(entries);
  const bestSetup = setupPerformance[0];
  const worstSetup = setupPerformance[setupPerformance.length - 1];
  
  insights.push({
    pattern: {
      type: 'setup',
      name: 'setup_performance_divergence',
      description: `You perform well on ${bestSetup.type} (${bestSetup.winRate}% win rate) but struggle with ${worstSetup.type} (${worstSetup.winRate}% win rate)`,
      confidence: 85,
      occurrences: bestSetup.count + worstSetup.count
    },
    suggestion: `Focus on ${bestSetup.type} setups and skip ${worstSetup.type} until you've studied why they don't work for you`,
    actionable: true
  });
  
  return insights;
}
```

---

## INSIGHT DELIVERY

### When to Surface Insights

1. **Post-Entry** (after submission): Show 1-2 most relevant insights
2. **Weekly Review**: Comprehensive pattern report
3. **Pre-Trade** (if enabled): Warning if similar conditions to past losses
4. **On Demand**: User can request "Show me my patterns"

### Insight UI Templates

```
🧠 AI INSIGHT

**Pattern Detected:** Revenge Trading Loop
Confidence: 85% | Seen: 5 times in last 30 entries

**What's happening:**
When you lose a trade, you tend to re-enter within 10 minutes with larger size and less planning. This has resulted in losses 4 out of 5 times.

**Recommendation:**
Set a 15-minute cooldown timer after any loss. Journal the loss before considering your next trade.

[View Related Entries →] [This Was Helpful 👍 | Not Helpful 👎]
```

---

## INTEGRATION WITH OTHER LAYERS

### → Layer 01 (Hero's Journey)
- Patterns inform archetype identification (e.g., revenge loop = shadow work)
- Insights feed into transformation scoring

### → Layer 02 (Badges)
- Pattern recognition unlocks "Awareness" badges
- Breaking patterns awards "Threshold Crossing" badges

### → Layer 04 (Community)
- Anonymized patterns contribute to community heatmaps
- Most common patterns surfaced as collective insights

---

## USER CONTROLS & PRIVACY

```typescript
interface AIInsightsSettings {
  enabled: boolean;
  preTradeWarnings: boolean;         // Warn before entering similar bad trades
  weeklyReports: boolean;            // Email/push weekly pattern summary
  sharingConsent: boolean;           // Contribute patterns to community heatmaps
  minConfidenceThreshold: number;    // Only show insights with X% confidence
}
```

**STATUS**: ✅ Layer 03 Complete | AI Insights & Pattern Recognition Defined
