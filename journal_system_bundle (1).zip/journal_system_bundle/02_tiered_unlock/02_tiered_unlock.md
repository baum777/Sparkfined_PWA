# 02 — TIERED UNLOCK LAYER (BADGES & PROGRESSION)

## PURPOSE

The Tiered Unlock Layer implements a **quality-driven progression system** that rewards depth, consistency, and transformation over pure trading performance. It replaces traditional "win percentage" gamification with psychological growth metrics.

This layer handles:
- Badge criteria & awarding
- XP calculation & level progression
- Streak tracking & bonuses
- Quality scoring (AI-assessed)
- Unlock trees & gated features
- NFT minting for diamond-tier badges

---

## PHILOSOPHICAL FOUNDATION

### Why Quality Over Performance?

Traditional trading platforms reward P&L. This creates:
- ❌ Shame when losing (avoid journaling losses)
- ❌ Ego inflation when winning (avoid critical reflection)
- ❌ Performance anxiety (fear of "breaking streak")

**Sparkfined rewards the PROCESS, not the OUTCOME:**
- ✅ Journal a loss with honest reflection → Earn XP
- ✅ Recognize a pattern before acting → Earn badge
- ✅ Stay consistent through drawdown → Unlock features

**Core Principle:** You can't control the market. You CAN control your discipline, honesty, and growth. That's what we measure.

---

## BADGE SYSTEM ARCHITECTURE

### Badge Categories (5 Types)

```typescript
enum BadgeCategory {
  CONSISTENCY = 'consistency',       // Streak-based (daily journaling)
  DEPTH = 'depth',                   // Reflection quality (L1-L5)
  AWARENESS = 'awareness',           // Pattern recognition
  GROWTH = 'growth',                 // Transformation arc
  COMMUNITY = 'community'            // Social learning contribution
}
```

### Badge Tiers (4 Levels)

```typescript
enum BadgeTier {
  BRONZE = 'bronze',      // Entry-level achievement
  SILVER = 'silver',      // Consistent effort
  GOLD = 'gold',          // Advanced mastery
  DIAMOND = 'diamond'     // Elite/NFT-worthy
}
```

### Badge Schema (Inherited from Global)

```typescript
interface Badge {
  badgeId: string;
  name: string;
  tier: BadgeTier;
  category: BadgeCategory;
  description: string;
  xpValue: number;
  unlockedAt: timestamp;
  onChain: boolean;              // NFT minted?
  
  criteria: {
    type: 'streak' | 'quality' | 'insight' | 'community' | 'transformation';
    threshold: number;
    metric: string;
  };
}
```

---

## BADGE LIBRARY (COMPLETE LIST)

### 🔥 CONSISTENCY BADGES

#### Bronze Tier
```typescript
{
  name: "First Step",
  tier: "bronze",
  category: "consistency",
  description: "Journal your first trade. The journey begins.",
  xpValue: 10,
  criteria: {
    type: "streak",
    threshold: 1,
    metric: "entries_total"
  }
}
```

#### Silver Tier
```typescript
{
  name: "Week Warrior",
  tier: "silver",
  category: "consistency",
  description: "Journal for 7 consecutive days. Discipline is forming.",
  xpValue: 50,
  criteria: {
    type: "streak",
    threshold: 7,
    metric: "streak_current"
  }
}
```

#### Gold Tier
```typescript
{
  name: "Moon Cycle",
  tier: "gold",
  category: "consistency",
  description: "Journal for 30 consecutive days. Rare discipline.",
  xpValue: 150,
  criteria: {
    type: "streak",
    threshold: 30,
    metric: "streak_current"
  }
}
```

#### Diamond Tier
```typescript
{
  name: "Eternal Flame",
  tier: "diamond",
  category: "consistency",
  description: "Journal for 100 consecutive days. Mastery through consistency.",
  xpValue: 500,
  onChain: true,                    // NFT minted
  criteria: {
    type: "streak",
    threshold: 100,
    metric: "streak_current"
  }
}
```

---

### 🧠 DEPTH BADGES

#### Bronze Tier
```typescript
{
  name: "Surface Diver",
  tier: "bronze",
  category: "depth",
  description: "Complete your first L2 entry (pre-trade thoughts).",
  xpValue: 15,
  criteria: {
    type: "quality",
    threshold: 1,
    metric: "l2_entries_count"
  }
}
```

#### Silver Tier
```typescript
{
  name: "Emotion Tracker",
  tier: "silver",
  category: "depth",
  description: "Complete 10 L3 entries (emotion reflection).",
  xpValue: 50,
  criteria: {
    type: "quality",
    threshold: 10,
    metric: "l3_entries_count"
  }
}
```

#### Gold Tier
```typescript
{
  name: "Lesson Learner",
  tier: "gold",
  category: "depth",
  description: "Complete 25 L4 entries (post-trade lessons).",
  xpValue: 150,
  criteria: {
    type: "quality",
    threshold: 25,
    metric: "l4_entries_count"
  }
}
```

#### Diamond Tier
```typescript
{
  name: "Meta Mind",
  tier: "diamond",
  category: "depth",
  description: "Complete 50 L5 entries (meta-insights). True mastery.",
  xpValue: 500,
  onChain: true,
  criteria: {
    type: "quality",
    threshold: 50,
    metric: "l5_entries_count"
  }
}
```

---

### 👁️ AWARENESS BADGES

#### Bronze Tier
```typescript
{
  name: "Pattern Seeker",
  tier: "bronze",
  category: "awareness",
  description: "Identify your first recurring pattern (AI-assisted).",
  xpValue: 20,
  criteria: {
    type: "insight",
    threshold: 1,
    metric: "patterns_identified"
  }
}
```

#### Silver Tier
```typescript
{
  name: "Shadow Worker",
  tier: "silver",
  category: "awareness",
  description: "Complete 5 Shadow Work entries (facing fears/greed).",
  xpValue: 75,
  criteria: {
    type: "insight",
    threshold: 5,
    metric: "shadow_work_entries"
  }
}
```

#### Gold Tier
```typescript
{
  name: "Threshold Crosser",
  tier: "gold",
  category: "awareness",
  description: "Break 3 negative patterns (first-time positive behaviors).",
  xpValue: 200,
  criteria: {
    type: "insight",
    threshold: 3,
    metric: "threshold_crossings"
  }
}
```

#### Diamond Tier
```typescript
{
  name: "Oracle",
  tier: "diamond",
  category: "awareness",
  description: "Recognize patterns before acting (10+ documented cases).",
  xpValue: 600,
  onChain: true,
  criteria: {
    type: "insight",
    threshold: 10,
    metric: "proactive_pattern_recognition"
  }
}
```

---

### 🌱 GROWTH BADGES

#### Bronze Tier
```typescript
{
  name: "First Honest Loss",
  tier: "bronze",
  category: "growth",
  description: "Journal a losing trade with honest reflection.",
  xpValue: 25,
  criteria: {
    type: "transformation",
    threshold: 1,
    metric: "loss_entries_with_quality_80plus"
  }
}
```

#### Silver Tier
```typescript
{
  name: "Phase Shifter",
  tier: "silver",
  category: "growth",
  description: "Advance from DEGEN to SEEKER phase.",
  xpValue: 100,
  criteria: {
    type: "transformation",
    threshold: 1,
    metric: "phase_transitions"
  }
}
```

#### Gold Tier
```typescript
{
  name: "Discipline Forged",
  tier: "gold",
  category: "growth",
  description: "Reach WARRIOR phase. Consistency is automatic.",
  xpValue: 250,
  criteria: {
    type: "transformation",
    threshold: 1,
    metric: "warrior_phase_reached"
  }
}
```

#### Diamond Tier
```typescript
{
  name: "Sage Awakened",
  tier: "diamond",
  category: "growth",
  description: "Reach SAGE phase. You've completed the Hero's Journey.",
  xpValue: 1000,
  onChain: true,
  criteria: {
    type: "transformation",
    threshold: 1,
    metric: "sage_phase_reached"
  }
}
```

---

### 🤝 COMMUNITY BADGES

#### Bronze Tier
```typescript
{
  name: "First Share",
  tier: "bronze",
  category: "community",
  description: "Share your first journal entry with the community.",
  xpValue: 15,
  criteria: {
    type: "community",
    threshold: 1,
    metric: "public_entries_count"
  }
}
```

#### Silver Tier
```typescript
{
  name: "Wisdom Giver",
  tier: "silver",
  category: "community",
  description: "Share 10 high-quality insights with the community.",
  xpValue: 75,
  criteria: {
    type: "community",
    threshold: 10,
    metric: "public_l4_l5_entries"
  }
}
```

#### Gold Tier
```typescript
{
  name: "Mentor",
  tier: "gold",
  category: "community",
  description: "Your insights helped 100+ traders (upvotes/references).",
  xpValue: 300,
  criteria: {
    type: "community",
    threshold: 100,
    metric: "community_impact_score"
  }
}
```

#### Diamond Tier
```typescript
{
  name: "Elixir Bearer",
  tier: "diamond",
  category: "community",
  description: "You've returned with the elixir. Your wisdom is legendary.",
  xpValue: 800,
  onChain: true,
  criteria: {
    type: "community",
    threshold: 500,
    metric: "community_impact_score"
  }
}
```

---

## XP CALCULATION (DETAILED FORMULA)

### Base XP (Depth Multiplier)

```typescript
const BASE_XP = 10;

const DEPTH_MULTIPLIERS = {
  1: 1.0,   // L1 only (trade data) → 10 XP
  2: 1.5,   // + pre-trade thoughts  → 15 XP
  3: 2.0,   // + emotions            → 20 XP
  4: 3.0,   // + lessons             → 30 XP
  5: 5.0    // + meta-insights       → 50 XP
};

function calculateBaseXP(reflectionDepth: number): number {
  return BASE_XP * DEPTH_MULTIPLIERS[reflectionDepth];
}
```

### Quality Bonus (AI-Assessed 0-100)

```typescript
function calculateQualityBonus(entry: JournalEntry): number {
  // Quality score from AI (specificity, honesty, clarity)
  const qualityScore = entry.reflection.qualityScore; // 0-100
  
  // Convert to XP bonus (max +50 XP)
  return qualityScore * 0.5;
}

// EXAMPLES:
// Quality 50 → +25 XP
// Quality 80 → +40 XP
// Quality 100 → +50 XP
```

### Streak Bonus (Consistency Reward)

```typescript
function calculateStreakBonus(user: UserProfile): number {
  const streak = user.streakCurrent;
  
  // 2 XP per day of streak, capped at 50 XP
  return Math.min(streak * 2, 50);
}

// EXAMPLES:
// 3-day streak → +6 XP
// 10-day streak → +20 XP
// 25+ day streak → +50 XP (cap)
```

### Transformation Bonus (Growth Reward)

```typescript
function calculateTransformationBonus(entry: JournalEntry): number {
  // Transformation score from Layer 01 (0-100)
  const transformationScore = entry.narrative.transformationScore;
  
  // Convert to XP bonus (max +30 XP)
  return transformationScore * 0.3;
}

// EXAMPLES:
// Transformation 50 → +15 XP
// Transformation 80 → +24 XP
// Transformation 100 → +30 XP
```

### Total XP Formula

```typescript
function calculateTotalXP(entry: JournalEntry, user: UserProfile): number {
  const baseXP = calculateBaseXP(entry.reflection.reflectionDepth);
  const qualityBonus = calculateQualityBonus(entry);
  const streakBonus = calculateStreakBonus(user);
  const transformationBonus = calculateTransformationBonus(entry);
  
  return Math.floor(baseXP + qualityBonus + streakBonus + transformationBonus);
}
```

### Example Calculations

```typescript
// EXAMPLE 1: Minimal Entry
// L1 depth, quality 30, 0-day streak, transformation 0
baseXP = 10 * 1.0 = 10
qualityBonus = 30 * 0.5 = 15
streakBonus = 0 * 2 = 0
transformationBonus = 0 * 0.3 = 0
TOTAL = 25 XP

// EXAMPLE 2: Solid Entry
// L3 depth, quality 70, 5-day streak, transformation 50
baseXP = 10 * 2.0 = 20
qualityBonus = 70 * 0.5 = 35
streakBonus = 5 * 2 = 10
transformationBonus = 50 * 0.3 = 15
TOTAL = 80 XP

// EXAMPLE 3: Mastery Entry
// L5 depth, quality 95, 15-day streak, transformation 85
baseXP = 10 * 5.0 = 50
qualityBonus = 95 * 0.5 = 47.5 (~48)
streakBonus = 15 * 2 = 30
transformationBonus = 85 * 0.3 = 25.5 (~26)
TOTAL = 154 XP
```

---

## LEVEL PROGRESSION

### Level Thresholds

```typescript
const LEVEL_THRESHOLDS: Record<number, number> = {
  1: 0,
  2: 100,
  3: 250,
  4: 500,
  5: 1000,
  6: 1500,
  7: 2000,
  8: 2500,
  9: 3000,
  10: 3500,
  11: 4000,
  12: 4500,
  13: 5000,
  14: 6000,
  15: 7000,
  16: 8000,
  17: 9000,
  18: 10000,
  19: 12000,
  20: 15000,
  // Exponential curve continues...
};

function calculateLevel(totalXP: number): number {
  const levels = Object.entries(LEVEL_THRESHOLDS)
    .map(([level, threshold]) => ({ level: parseInt(level), threshold }))
    .reverse();
  
  for (const { level, threshold } of levels) {
    if (totalXP >= threshold) return level;
  }
  
  return 1;
}
```

### Level-Gated Features

```typescript
const FEATURE_UNLOCKS: Record<number, string[]> = {
  1: ["Basic journaling"],
  3: ["Emotion tracking (L3)"],
  5: ["AI pattern detection"],
  10: ["Community heatmaps (read-only)"],
  15: ["Public sharing", "Teaching mode"],
  20: ["Community heatmaps (contribute)", "Advanced AI insights"],
};
```

---

## QUALITY SCORING (AI ASSESSMENT)

### How AI Evaluates Quality (0-100 Scale)

```typescript
function calculateQualityScore(entry: JournalEntry): number {
  let score = 0;
  
  // 1. SPECIFICITY (30 points)
  // Are the reflections specific or generic?
  const specificity = assessSpecificity(entry.reflection);
  score += specificity * 30;
  
  // 2. HONESTY (30 points)
  // Does user admit difficult emotions or rationalize?
  const honesty = assessHonesty(entry.reflection);
  score += honesty * 30;
  
  // 3. CLARITY (20 points)
  // Is the writing clear and coherent?
  const clarity = assessClarity(entry.reflection);
  score += clarity * 20;
  
  // 4. ACTIONABILITY (20 points)
  // Does the lesson lead to a concrete action?
  const actionability = assessActionability(entry.reflection);
  score += actionability * 20;
  
  return Math.min(Math.round(score), 100);
}

// SUB-FUNCTIONS (AI NLP Tasks)

function assessSpecificity(reflection: Reflection): number {
  // HIGH: "I moved my stop from 42k to 41.5k because I got scared"
  // LOW: "I made a mistake"
  
  const hasSpecificDetails = [
    reflection.preTradeThoughts.length > 50,
    reflection.duringTradeEmotions.includes('because'),
    reflection.postTradeLessons.includes('next time')
  ].filter(Boolean).length;
  
  return hasSpecificDetails / 3; // 0-1 scale
}

function assessHonesty(reflection: Reflection): number {
  // HIGH: "I was scared and panicked"
  // LOW: "The market was uncertain"
  
  const emotionKeywords = ['scared', 'fear', 'greed', 'panic', 'regret'];
  const hasEmotionalHonesty = emotionKeywords.some(kw => 
    reflection.duringTradeEmotions.toLowerCase().includes(kw)
  );
  
  const avoidsRationalization = !reflection.postTradeLessons.toLowerCase()
    .includes('market was');
  
  return (hasEmotionalHonesty && avoidsRationalization) ? 1.0 : 0.5;
}

function assessClarity(reflection: Reflection): number {
  // Check readability, sentence structure
  const avgSentenceLength = calculateAvgSentenceLength(reflection.postTradeLessons);
  
  // Ideal: 10-20 words per sentence
  if (avgSentenceLength >= 10 && avgSentenceLength <= 20) return 1.0;
  if (avgSentenceLength >= 5 && avgSentenceLength <= 30) return 0.7;
  return 0.4;
}

function assessActionability(reflection: Reflection): number {
  // HIGH: "Next time, I will X"
  // LOW: "I need to do better"
  
  const actionPhrases = ['next time', 'will', 'going to', 'plan to'];
  const hasAction = actionPhrases.some(phrase => 
    reflection.postTradeLessons.toLowerCase().includes(phrase)
  );
  
  return hasAction ? 1.0 : 0.3;
}
```

---

## STREAK SYSTEM

### Streak Rules

```typescript
interface StreakRules {
  resetHour: number;              // UTC hour when day resets (e.g., 5 = 5am UTC)
  gracePeriod: number;            // Hours of grace before streak breaks (e.g., 24)
  freezeAvailable: boolean;       // Can user "freeze" streak for 1 day?
}

const DEFAULT_STREAK_RULES: StreakRules = {
  resetHour: 5,                   // 5am UTC = midnight PST
  gracePeriod: 24,                // 24 hours grace
  freezeAvailable: true           // Users can freeze once per month
};
```

### Streak Tracking Logic

```typescript
function updateStreak(user: UserProfile, entryTimestamp: timestamp): void {
  const now = entryTimestamp;
  const lastEntry = user.lastEntryTimestamp;
  
  if (!lastEntry) {
    // First entry ever
    user.streakCurrent = 1;
    user.streakLongest = 1;
    return;
  }
  
  const hoursSinceLastEntry = (now - lastEntry) / (1000 * 60 * 60);
  
  if (hoursSinceLastEntry <= 24) {
    // Same day or next day
    user.streakCurrent += 1;
  } else if (hoursSinceLastEntry <= 48 && user.streakFreezeAvailable) {
    // Grace period (or freeze used)
    user.streakCurrent += 1;
    user.streakFreezeUsed = true;
  } else {
    // Streak broken
    user.streakCurrent = 1;
  }
  
  // Update longest streak
  if (user.streakCurrent > user.streakLongest) {
    user.streakLongest = user.streakCurrent;
  }
  
  user.lastEntryTimestamp = now;
}
```

---

## UNLOCK TREE (PROGRESSIVE FEATURE ACCESS)

### Feature Tiers

```typescript
interface FeatureUnlock {
  featureName: string;
  requiredLevel: number;
  requiredBadge?: string;
  description: string;
}

const UNLOCK_TREE: FeatureUnlock[] = [
  {
    featureName: "Basic Journal Entry (L1-L2)",
    requiredLevel: 1,
    description: "Log trades and basic thoughts"
  },
  {
    featureName: "Emotion Tracking (L3)",
    requiredLevel: 3,
    description: "Unlock emotion reflection prompts"
  },
  {
    featureName: "AI Pattern Detection (Read-Only)",
    requiredLevel: 5,
    description: "See patterns AI detects in your entries"
  },
  {
    featureName: "Lesson Extraction (L4)",
    requiredLevel: 7,
    description: "Unlock post-trade lesson prompts"
  },
  {
    featureName: "Community Heatmaps (Read-Only)",
    requiredLevel: 10,
    description: "View anonymized community patterns"
  },
  {
    featureName: "Meta-Insights (L5)",
    requiredLevel: 12,
    description: "Unlock highest reflection depth"
  },
  {
    featureName: "Public Sharing",
    requiredLevel: 15,
    requiredBadge: "Wisdom Giver",
    description: "Share your insights with the community"
  },
  {
    featureName: "Community Heatmaps (Contribute)",
    requiredLevel: 20,
    description: "Your data contributes to community insights"
  },
  {
    featureName: "Advanced AI Insights",
    requiredLevel: 25,
    requiredBadge: "Oracle",
    description: "Predictive pattern recognition"
  },
  {
    featureName: "NFT Badge Minting",
    requiredLevel: 30,
    description: "Mint diamond badges as NFTs"
  }
];
```

---

## BADGE AWARDING LOGIC

### Check & Award Badges (Trigger After Each Entry)

```typescript
async function checkAndAwardBadges(userId: string, entry: JournalEntry): Promise<Badge[]> {
  const user = await getUserProfile(userId);
  const awardedBadges: Badge[] = [];
  
  // Get all badge definitions
  const allBadges = BADGE_LIBRARY; // From above
  
  for (const badgeDef of allBadges) {
    // Skip if already earned
    if (user.badgesEarned.some(b => b.badgeId === badgeDef.badgeId)) {
      continue;
    }
    
    // Check criteria
    const meetsRequirement = await checkBadgeCriteria(user, badgeDef, entry);
    
    if (meetsRequirement) {
      // Award badge
      const badge: Badge = {
        ...badgeDef,
        unlockedAt: Date.now()
      };
      
      user.badgesEarned.push(badge);
      user.xpTotal += badge.xpValue;
      awardedBadges.push(badge);
      
      // If diamond tier, trigger NFT minting (if enabled)
      if (badge.tier === 'diamond' && badge.onChain) {
        await mintBadgeNFT(user, badge);
      }
    }
  }
  
  // Update user profile
  await saveUserProfile(user);
  
  return awardedBadges;
}

async function checkBadgeCriteria(
  user: UserProfile, 
  badge: BadgeDefinition, 
  latestEntry: JournalEntry
): Promise<boolean> {
  
  switch (badge.criteria.type) {
    case 'streak':
      return user.streakCurrent >= badge.criteria.threshold;
    
    case 'quality':
      const metric = badge.criteria.metric;
      if (metric === 'l2_entries_count') {
        return countEntriesByDepth(user, 2) >= badge.criteria.threshold;
      }
      if (metric === 'l3_entries_count') {
        return countEntriesByDepth(user, 3) >= badge.criteria.threshold;
      }
      // ... etc for L4, L5
      break;
    
    case 'insight':
      if (badge.criteria.metric === 'patterns_identified') {
        return user.patternsIdentified >= badge.criteria.threshold;
      }
      if (badge.criteria.metric === 'shadow_work_entries') {
        return countEntriesByArchetype(user, 'shadow_work') >= badge.criteria.threshold;
      }
      // ... etc
      break;
    
    case 'transformation':
      if (badge.criteria.metric === 'phase_transitions') {
        return user.phaseTransitions >= badge.criteria.threshold;
      }
      if (badge.criteria.metric === 'warrior_phase_reached') {
        return user.journeyPhase === 'warrior' || user.journeyPhase === 'master' || user.journeyPhase === 'sage';
      }
      // ... etc
      break;
    
    case 'community':
      if (badge.criteria.metric === 'public_entries_count') {
        return user.publicEntriesCount >= badge.criteria.threshold;
      }
      if (badge.criteria.metric === 'community_impact_score') {
        return user.communityImpactScore >= badge.criteria.threshold;
      }
      break;
  }
  
  return false;
}
```

---

## NFT MINTING (DIAMOND BADGES)

### Integration with Token/NFT System

```typescript
interface BadgeNFT {
  badgeId: string;
  userId: string;
  contractAddress: string;
  tokenId: string;
  mintedAt: timestamp;
  metadata: {
    name: string;
    description: string;
    image: string;              // IPFS link to badge artwork
    attributes: {
      tier: 'diamond';
      category: string;
      earnedAt: timestamp;
      journeyPhase: string;
    };
  };
}

async function mintBadgeNFT(user: UserProfile, badge: Badge): Promise<void> {
  // 1. Generate metadata
  const metadata = {
    name: `${badge.name} - Sparkfined Badge`,
    description: badge.description,
    image: `ipfs://${badge.artworkCID}`,
    attributes: {
      tier: 'diamond',
      category: badge.category,
      earnedAt: badge.unlockedAt,
      journeyPhase: user.journeyPhase
    }
  };
  
  // 2. Upload metadata to IPFS
  const metadataURI = await uploadToIPFS(metadata);
  
  // 3. Call smart contract to mint
  const tx = await BadgeNFTContract.mint(
    user.walletAddress,
    badge.badgeId,
    metadataURI
  );
  
  await tx.wait();
  
  // 4. Update user record
  badge.onChain = true;
  badge.nftTokenId = tx.tokenId;
  
  // 5. Notify user
  await sendNotification(user.userId, {
    type: 'badge_nft_minted',
    badge: badge.name,
    txHash: tx.hash
  });
}
```

---

## UI/UX CONSIDERATIONS

### Badge Display

```typescript
// Badge Card Component (React)
interface BadgeCardProps {
  badge: Badge;
  progress?: number;  // 0-100 if in-progress, undefined if locked
  locked?: boolean;
}

// STATES:
// 1. LOCKED (gray, requirements shown)
// 2. IN_PROGRESS (colored, progress bar)
// 3. EARNED (full color, glow effect, "View NFT" if diamond)
```

### Progress Indicators

```
📊 YOUR PROGRESSION

Level 8 → Level 9 (2500 / 3000 XP)
[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░] 83%

🔥 Streak: 12 days (+24 XP per entry)

🎖️ Next Badge: "Moon Cycle" (30-day streak)
   ➜ 18 more days

⚡ Quality Score: 78/100 (Last 10 entries avg)
```

---

## GAMIFICATION PSYCHOLOGY

### What Makes This Different

Traditional gamification:
- Rewards outcomes → Creates anxiety
- Punishes failure → Creates avoidance
- Focuses on competition → Creates comparison

Sparkfined gamification:
- ✅ Rewards process → Creates intrinsic motivation
- ✅ Honors honesty → Creates psychological safety
- ✅ Focuses on growth → Creates self-comparison

**Key Insight:** If a user loses money but journals honestly with deep reflection, they should feel REWARDED, not punished. That's the core design principle.

---

## INTEGRATION WITH OTHER LAYERS

### → Layer 01 (Hero's Journey)
- Journey phase determines unlock access
- Transformation score feeds into Growth badges
- Archetype completion unlocks narrative badges

### → Layer 03 (AI Insights)
- Quality score used for badge criteria
- Pattern recognition feeds Awareness badges

### → Layer 04 (Community)
- Public sharing unlocks Community badges
- Community impact score tracked for Mentor badges

---

## KEY METRICS TO TRACK

```typescript
interface ProgressionMetrics {
  // XP & LEVELS
  xpTotal: number;
  level: number;
  xpToNextLevel: number;
  
  // STREAKS
  streakCurrent: number;
  streakLongest: number;
  streakFreezeAvailable: boolean;
  
  // BADGES
  badgesEarned: Badge[];
  badgesInProgress: { badgeId: string; progress: number }[];
  badgesLocked: string[];
  
  // QUALITY
  avgQualityScore: number;        // Last 10 entries
  avgDepth: number;               // Last 10 entries
  
  // UNLOCKS
  featuresUnlocked: string[];
  featuresLocked: string[];
}
```

---

**STATUS**: ✅ Layer 02 Complete | Ready for Layer 03 Integration
