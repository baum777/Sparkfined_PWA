# SUB-PROMPTS: Tiered Unlock Layer (Layer 02)

## SP-02-01: Calculate and Display XP Earned

**CONTEXT:** User just completed a journal entry. System calculates XP.

**PROMPT:**
```
✅ Entry Saved!

🎯 XP EARNED: {TOTAL_XP}

Breakdown:
- Base (L{depth}): {base_xp} XP
- Quality Bonus: +{quality_bonus} XP
- Streak Bonus ({streak} days): +{streak_bonus} XP
- Transformation: +{transformation_bonus} XP

Total XP: {current_total} / {next_level_threshold}
Level {level} → Level {level+1} ({xp_remaining} XP remaining)
```

---

## SP-02-02: Badge Earned Notification

**CONTEXT:** User unlocked a badge after entry submission.

**PROMPT:**
```
🎖️ BADGE UNLOCKED!

**{BADGE_NAME}** ({TIER})

"{DESCRIPTION}"

+{XP_VALUE} XP

[View Badge Collection →]
```

---

## SP-02-03: Level Up Notification

**CONTEXT:** User's XP crossed level threshold.

**PROMPT:**
```
⚡ LEVEL UP!

You're now **Level {NEW_LEVEL}**

NEW UNLOCKS:
{list_of_features}

Keep journaling to unlock more!
```

---

## SP-02-04: Streak Milestone

**CONTEXT:** User hits 7, 30, or 100 day streak.

**PROMPT:**
```
🔥 {STREAK_LENGTH}-DAY STREAK!

You're earning +{bonus} XP per entry from your streak.

{if 7 days}: "Week Warrior badge unlocked!"
{if 30 days}: "Moon Cycle badge unlocked!"
{if 100 days}: "Eternal Flame badge unlocked (NFT)!"
```

---

## SP-02-05: Quality Score Feedback

**CONTEXT:** User completed entry. AI assessed quality.

**PROMPT:**
```
📊 QUALITY SCORE: {score}/100

{if score < 50}:
"To improve, try being more specific. Instead of 'I made a mistake', say 'I moved my stop from X to Y because I panicked.'"

{if score 50-79}:
"Solid reflection. To reach 80+, add more actionable lessons ('Next time, I will...')."

{if score 80+}:
"Excellent quality! This depth of reflection is where transformation happens."
```

---

## SP-02-06: Badge Progress Check

**CONTEXT:** User asks "What badges am I close to?"

**PROMPT:**
```
🎯 BADGES IN PROGRESS:

1. **{Badge Name}** ({Tier})
   [{progress_bar}] {current}/{required}
   ➜ {remaining} more to unlock

2. **{Badge Name}** ({Tier})
   [{progress_bar}] {current}/{required}
   ➜ {remaining} more to unlock

Focus on #{1}—you're closest!
```

---

## SP-02-07: Streak Broken Warning

**CONTEXT:** User's streak is about to break (23 hours since last entry).

**PROMPT:**
```
⚠️ STREAK ALERT

Your {STREAK_LENGTH}-day streak ends in {HOURS} hours.

Journal now to keep it alive and earn streak bonus XP!

[Quick Entry →]
```

---

## SP-02-08: NFT Minting Notification

**CONTEXT:** Diamond badge earned, NFT minting triggered.

**PROMPT:**
```
💎 DIAMOND BADGE → NFT MINTING

Your **{BADGE_NAME}** badge is being minted on-chain...

[View Transaction →]

This NFT is yours forever—proof of your mastery.
```

---

## SP-02-09: Feature Unlock Notification

**CONTEXT:** User leveled up and unlocked new feature.

**PROMPT:**
```
🔓 NEW FEATURE UNLOCKED

**{FEATURE_NAME}**

{DESCRIPTION}

[Try It Now →]
```

---

## SP-02-10: XP Optimization Tips

**CONTEXT:** User asks how to earn more XP.

**PROMPT:**
```
💡 XP OPTIMIZATION TIPS

Current Avg: {avg_xp} XP per entry

To earn more:
1. Go deeper (L{current_depth} → L{current_depth+1}) = +{xp_diff} XP base
2. Maintain streak ({current_streak} days) = +{streak_bonus} XP per entry
3. Improve quality ({current_quality}/100) → aim for 80+ = +{potential_bonus} XP

Max potential per entry: ~150 XP (L5 + quality 100 + 25-day streak + high transformation)
```

**STATUS**: ✅ Layer 02 Sub-Prompts Complete
