# SUB-PROMPTS: Hero's Journey Layer (Layer 01)

## PURPOSE

These are **granular action prompts** that Claude (or the system) uses for specific tasks within the Hero's Journey layer. Each prompt is designed to be used in isolation for a specific user action.

---

## CATEGORY: ENTRY CREATION

### SP-01-01: Prompt User for L2 Reflection (Pre-Trade Thoughts)

**CONTEXT:** User has submitted L1 data (trade details). System wants to encourage L2 reflection.

**PROMPT:**
```
Great! You've logged the trade data. Now let's go a bit deeper:

**What was your plan before entering this trade?**
- What setup did you see?
- What was your hypothesis?
- Where were your entry, stop, and target?

(You can skip this if you're short on time, but deeper reflection = more XP and better insights.)
```

**EXPECTED INPUT:** Text response (20-500 characters recommended)

**AI TASK AFTER RESPONSE:**
- If response contains "setup", "plan", "hypothesis" → Tag as `planned_entry`
- If response is vague (<20 chars) or "idk" → Tag as `impulsive_entry`
- Calculate `reflectionDepth = 2`

---

### SP-01-02: Prompt User for L3 Reflection (Emotions During Trade)

**CONTEXT:** User has completed L2 or skipped to L3. System wants to surface emotional awareness.

**PROMPT:**
```
Now the important part: **How did you feel during this trade?**

Were you:
- Calm and confident?
- Anxious or scared?
- Excited or euphoric?
- Frustrated or angry?
- Something else?

Be honest—there's no "right" emotion. This is data.
```

**EXPECTED INPUT:** Text response describing emotions

**AI TASK AFTER RESPONSE:**
- Extract `emotionTags` using keyword matching:
  - "scared", "nervous" → `fear`
  - "confident", "calm" → `confidence`
  - "fomo", "missed" → `fomo`
  - "revenge", "angry" → `revenge`
  - etc.
- Calculate `reflectionDepth = 3`

---

### SP-01-03: Prompt User for L4 Reflection (Post-Trade Lessons)

**CONTEXT:** User has shared emotions (L3). System wants to extract lessons learned.

**PROMPT:**
```
Awesome. Now zoom out: **What did you learn from this trade?**

- What worked? What didn't?
- What would you do differently next time?
- What pattern are you noticing?

(This is where the real growth happens.)
```

**EXPECTED INPUT:** Text response with explicit lesson

**AI TASK AFTER RESPONSE:**
- Assess lesson clarity (0-100 score based on specificity)
- If lesson mentions "rule", "discipline", "stop" → Tag as `rule_identified`
- Calculate `reflectionDepth = 4`

---

### SP-01-04: Prompt User for L5 Reflection (Meta-Insights)

**CONTEXT:** User has completed L4. System wants to encourage meta-awareness.

**PROMPT:**
```
Final question (optional but powerful):

**How does this trade fit into your bigger journey?**

- What deeper pattern are you seeing about yourself as a trader?
- Are you facing a fear (shadow work)?
- Are you breaking an old habit (threshold crossing)?
- What phase of the Hero's Journey are you in right now?

(If you're not sure, that's okay—skip this and come back to it later.)
```

**EXPECTED INPUT:** Text response connecting trade to broader journey

**AI TASK AFTER RESPONSE:**
- Extract journey phase awareness (does user mention DEGEN/SEEKER/etc.?)
- Calculate `transformationScore` (0-100 based on pattern recognition depth)
- Identify `archetype` (shadow_work, threshold_crossing, etc.)
- Calculate `reflectionDepth = 5`

---

### SP-01-05: Quick Entry Mode (Mobile-Optimized)

**CONTEXT:** User is on mobile or wants fast entry. System offers streamlined flow.

**PROMPT:**
```
Quick Entry Mode

1️⃣ **Trade Data**: [auto-filled if possible, else quick form]

2️⃣ **How did it feel?** (one word or phrase)
   - Tap: Calm | Anxious | FOMO | Revenge | Confident

3️⃣ **Quick Lesson**: (one sentence)
   - Example: "Moved my stop = loss"

✅ DONE (Earned 15-25 XP)

[Want to go deeper? Switch to Full Mode]
```

**AI TASK:**
- Accept minimal reflection
- Assign `reflectionDepth = 2` (basic + emotion)
- Still extract emotion tags and behaviors from minimal input

---

## CATEGORY: ARCHETYPE IDENTIFICATION

### SP-01-06: Identify Shadow Work Entry

**CONTEXT:** AI detects patterns suggesting shadow work (facing fears/greed/revenge)

**DETECTION CRITERIA:**
- `emotionTags` include `fear`, `regret`, `revenge`, `frustration`
- `behaviorTags` include `impulsive_entry`, `stop_moved`, `revenge_entry`
- Reflection text includes "I hate", "mistake", "why did I", "I always"

**PROMPT TO USER:**
```
I'm noticing something: This entry shows you facing a part of yourself that's uncomfortable—the impulsive side, the fearful side, the part that reacts instead of responds.

This is what's called **shadow work** in the Hero's Journey. It's painful but necessary. The fact that you're journaling it means you're not avoiding it. That's growth.

Does that resonate?
```

---

### SP-01-07: Identify Mentor Moment Entry

**CONTEXT:** AI detects evidence of discipline or following a rule/system

**DETECTION CRITERIA:**
- `behaviorTags` include `followed_plan`, `stop_respected`, `proper_size`
- Reflection text includes "remembered", "followed", "stuck to", "discipline"

**PROMPT TO USER:**
```
This is a **mentor moment**—you internalized a lesson from your system/mentor/rules and let it guide you instead of your emotions.

This is how discipline becomes automatic. You're in the WARRIOR phase (or approaching it). Keep doing this.
```

---

### SP-01-08: Identify Threshold Crossing Entry

**CONTEXT:** AI detects user doing something new or breaking a long-standing pattern

**DETECTION CRITERIA:**
- User explicitly says "first time" or "never done this before"
- Historical analysis shows this is the first occurrence of a positive behavior
- Example: First time taking a full loss without revenge trading

**PROMPT TO USER:**
```
🎉 **THRESHOLD CROSSING DETECTED**

You just did something you've never done before. This is a pivotal moment in the Hero's Journey—you're no longer the same trader you were yesterday.

Document this. You'll look back on this entry as a turning point.
```

---

### SP-01-09: Identify Ordeal Entry

**CONTEXT:** AI detects major loss or emotional crisis

**DETECTION CRITERIA:**
- `pnl` < -2x user's average loss
- `emotionTags` include `frustration`, `regret`, `doubt`
- Reflection text includes "worst", "brutal", "considering quitting", "hate this"

**PROMPT TO USER:**
```
This is an **ordeal**—the darkest part of the Hero's Journey. It feels like failure, but it's actually the test that separates those who quit from those who transform.

The fact that you're journaling this instead of rage-quitting means you're still in the game. That matters.

What's the smallest next step you can take to rebuild?
```

---

### SP-01-10: Identify Return with Elixir Entry

**CONTEXT:** AI detects user sharing wisdom or teaching others

**DETECTION CRITERIA:**
- Entry is set to `public` visibility
- `sharedToCommunity = true`
- Reflection includes teaching language: "my advice", "I've learned", "here's what worked"

**PROMPT TO USER:**
```
You're in the **Return with Elixir** phase—you've learned something valuable and you're sharing it with the community.

This is SAGE behavior. By teaching others, you solidify your own understanding. This is mastery.
```

---

## CATEGORY: JOURNEY PHASE FEEDBACK

### SP-01-11: User Asks "Where Am I in the Journey?"

**CONTEXT:** User explicitly asks about their journey phase

**PROMPT:**
```
Let me check your progress...

You're at **{XP_TOTAL} XP**, which puts you in **{JOURNEY_PHASE}** phase.

{PHASE_DESCRIPTION}

To reach the next phase ({NEXT_PHASE}), you need **{XP_NEEDED} more XP**.

How to earn XP faster:
- Journal deeper (L4-L5 entries = 3-5x XP)
- Be consistent (streak bonus = up to +50 XP per entry)
- Show transformation (honest insight = +30 XP bonus)

Keep going. You're on the path.
```

**VARIABLES TO REPLACE:**
- `{XP_TOTAL}` — User's current total XP
- `{JOURNEY_PHASE}` — Current phase (DEGEN, SEEKER, etc.)
- `{PHASE_DESCRIPTION}` — Narrative description from phase definitions
- `{NEXT_PHASE}` — Next phase in progression
- `{XP_NEEDED}` — XP remaining to next threshold

---

### SP-01-12: User Levels Up (Phase Transition)

**CONTEXT:** User's XP crosses a phase threshold (e.g., 500 XP → WARRIOR)

**PROMPT:**
```
🎉 **PHASE TRANSITION**

You've crossed into **{NEW_PHASE}** phase!

{PHASE_TRANSITION_NARRATIVE}

This is a milestone. You're not the same trader you were at the start. Keep journaling—the journey continues.

[View Your Journey Stats →]
```

**EXAMPLE:**
```
🎉 **PHASE TRANSITION**

You've crossed into **WARRIOR** phase!

You've moved beyond questioning and into discipline. You follow your rules most of the time. Emotion still hits, but you recognize it before acting. This is where real edge forms.

The next phase is MASTER (2001 XP). To get there, focus on pattern recognition—start seeing your setups *before* they fully form.

Keep going, Warrior.

[View Your Journey Stats →]
```

---

## CATEGORY: EMOTION/BEHAVIOR VALIDATION

### SP-01-13: Validate Extracted Emotions

**CONTEXT:** AI has extracted emotions from user's text. Needs user confirmation.

**PROMPT:**
```
Based on what you shared, I'm detecting these emotions:
- {EMOTION_1}
- {EMOTION_2}
- {EMOTION_3}

Does that feel accurate? (You can edit or add.)
```

**EXAMPLE:**
```
Based on what you shared, I'm detecting these emotions:
- FOMO (fear of missing out)
- Fear (panic during pullback)
- Regret (exited too early)

Does that feel accurate? (You can edit or add.)
```

---

### SP-01-14: Validate Extracted Behaviors

**CONTEXT:** AI has tagged behaviors based on entry data + reflection. Needs confirmation.

**PROMPT:**
```
I'm seeing these behavior patterns in this trade:
- {BEHAVIOR_1}: {EXPLANATION}
- {BEHAVIOR_2}: {EXPLANATION}

Sound right?
```

**EXAMPLE:**
```
I'm seeing these behavior patterns in this trade:
- Impulsive Entry: No documented plan before entering
- Stop Moved: You mentioned adjusting your stop during the trade
- Early Exit: You exited before your original target

Sound right?
```

---

## CATEGORY: TRANSFORMATION FEEDBACK

### SP-01-15: Recognize Pattern Awareness

**CONTEXT:** User explicitly connects current trade to past patterns

**PROMPT:**
```
🔥 **PATTERN RECOGNITION DETECTED**

You just connected this trade to a broader pattern you've noticed. This is meta-awareness—seeing the pattern *beneath* the pattern.

This is what separates SEEKER from MASTER. Keep doing this.
```

---

### SP-01-16: Recognize Emotional Honesty

**CONTEXT:** User admits difficult emotions (fear, greed, shame, revenge)

**PROMPT:**
```
Respect for the honesty. Most traders rationalize or intellectualize. You named the emotion directly.

Emotional honesty = data. Data = edge. You're doing the work.
```

---

### SP-01-17: Recognize Behavioral Shift

**CONTEXT:** AI detects user breaking a negative pattern (e.g., first time not revenge trading)

**PROMPT:**
```
⚡ **BEHAVIORAL SHIFT DETECTED**

Your last 5 trades showed {NEGATIVE_PATTERN}. This trade shows {POSITIVE_PATTERN}.

This is how change happens—one trade at a time. Document this moment. You're evolving.
```

**EXAMPLE:**
```
⚡ **BEHAVIORAL SHIFT DETECTED**

Your last 5 trades showed revenge trading after losses. This trade shows you took the loss and walked away.

This is how change happens—one trade at a time. Document this moment. You're evolving.
```

---

## CATEGORY: ENCOURAGEMENT & MOTIVATION

### SP-01-18: User Journaling After Loss

**CONTEXT:** User journals a losing trade (especially after streak of losses)

**PROMPT:**
```
Journaling after a loss takes guts. Most traders avoid it.

The fact that you're here, reflecting instead of reacting, means you're already ahead of 90% of traders.

Loss is data. Use it.
```

---

### SP-01-19: User on Losing Streak

**CONTEXT:** User has multiple consecutive losses

**PROMPT:**
```
Tough stretch. But you're still journaling, which means you haven't quit.

The SEEKER phase is messy. The WARRIOR phase is earned through stretches like this.

What's the smallest lesson you can extract from these losses? Start there.
```

---

### SP-01-20: User Hits First Week Streak

**CONTEXT:** User journals for 7 consecutive days

**PROMPT:**
```
🔥 **7-DAY STREAK**

You've journaled for a full week. Most traders quit by day 3.

Consistency beats intensity. You're building the foundation for real transformation.

[Claim Streak Badge →]
```

---

### SP-01-21: User Completes First L5 Entry

**CONTEXT:** User writes their first meta-insight reflection (L5 depth)

**PROMPT:**
```
🎯 **FIRST L5 ENTRY**

You just went to the deepest level of reflection—connecting this trade to your broader journey and patterns.

This is where mastery lives. Most traders never get here.

[Claim Deep Reflection Badge →]
```

---

## CATEGORY: ERROR HANDLING

### SP-01-22: Incomplete Entry (Missing L1 Data)

**CONTEXT:** User tries to submit entry without required trade data

**PROMPT:**
```
❌ **Entry Incomplete**

I need at least the basics to create a journal entry:
- Symbol
- Direction (long/short)
- Entry price
- Exit price
- P&L

Everything else (emotions, lessons, insights) is optional but encouraged.
```

---

### SP-01-23: Shallow Reflection After Claiming Deep

**CONTEXT:** User claims to have deep insights but provides <10 characters

**PROMPT:**
```
⚠️ **Reflection Too Brief**

You selected L4 (Post-Trade Lessons), but your response is only {CHAR_COUNT} characters.

For L4 depth, I need at least 20 characters—something specific like:
"I moved my stop based on fear, not logic. That cost me."

Want to expand on this?
```

---

## CATEGORY: WEEKLY/MONTHLY REVIEWS

### SP-01-24: Prompt Weekly Reflection

**CONTEXT:** User has journaled for 7+ days. System triggers weekly review.

**PROMPT:**
```
📊 **WEEKLY REVIEW**

You've logged {ENTRY_COUNT} trades this week. Let's reflect:

1. **Most Common Emotion:** {EMOTION}
2. **Most Common Behavior:** {BEHAVIOR}
3. **Biggest Win:** {BEST_TRADE}
4. **Toughest Loss:** {WORST_TRADE}

**Reflection Question:**
What's ONE pattern you noticed this week that you want to work on next week?
```

---

### SP-01-25: Prompt Monthly Deep Dive

**CONTEXT:** User completes 30 days of journaling

**PROMPT:**
```
🏆 **30-DAY MILESTONE**

You've been journaling for a month. That's rare discipline.

Let's do a deep review:

1. **Journey Phase:** Started at {START_PHASE}, now at {CURRENT_PHASE}
2. **Total XP Earned:** {XP_EARNED}
3. **Badges Unlocked:** {BADGE_COUNT}
4. **Archetype Distribution:**
   - Shadow Work: {COUNT}
   - Mentor Moments: {COUNT}
   - Threshold Crossings: {COUNT}

**Big Question:**
Who are you becoming as a trader? Write 2-3 sentences.
```

---

## USAGE INSTRUCTIONS

Each sub-prompt should be:
1. **Contextually triggered** by user action or system event
2. **Used in isolation** (don't chain multiple sub-prompts without user response)
3. **Validated with AI** after user responds (extract tags, calculate scores, etc.)

These prompts are the **micro-interactions** that make the Hero's Journey layer feel alive and responsive.

---

**STATUS**: ✅ Sub-Prompts Complete | Ready for Integration with Layer 02
