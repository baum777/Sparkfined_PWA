# 01 — HERO'S JOURNEY LAYER

## PURPOSE

The Hero's Journey Layer transforms the trading journal from a sterile logbook into a **narrative arc of personal transformation**. Every trade is a chapter, every reflection is a step on the path from DEGEN to SAGE.

This layer handles:
- Narrative-driven reflection prompts
- Emotion and behavior extraction
- Transformation tracking
- Journey phase progression
- Archetype mapping (Shadow Work, Mentor Moments, etc.)

---

## PHILOSOPHICAL FOUNDATION

### The Trader's Journey as Monomyth

Joseph Campbell's Hero's Journey maps perfectly to trader psychology:

```
ORDINARY WORLD (DEGEN)
↓
CALL TO ADVENTURE (First Big Loss)
↓
REFUSAL OF THE CALL (Denial, Revenge Trading)
↓
MEETING THE MENTOR (Discipline, System, Community)
↓
CROSSING THE THRESHOLD (First Journaled Trade)
↓
TESTS, ALLIES, ENEMIES (Consistency, Streaks, Relapses)
↓
APPROACH TO INMOST CAVE (Shadow Work - Facing Fears/Greed)
↓
ORDEAL (Major Drawdown or Breakthrough)
↓
REWARD (Pattern Recognition, Equanimity)
↓
THE ROAD BACK (Teaching Others)
↓
RESURRECTION (Full Integration of Lessons)
↓
RETURN WITH ELIXIR (SAGE - Mastery & Wisdom)
```

### Journey Phases Mapped to XP

| Phase | XP Range | Archetype | Dominant Pattern | Journal Focus |
|-------|----------|-----------|------------------|---------------|
| **DEGEN** | 0-100 | The Fool | Impulsive, reactive, FOMO-driven | "What happened?" (L1-L2) |
| **SEEKER** | 101-500 | The Orphan | Questioning patterns, inconsistent | "Why did I do that?" (L2-L3) |
| **WARRIOR** | 501-2000 | The Warrior | Disciplined, rule-following | "How did I feel?" (L3-L4) |
| **MASTER** | 2001-5000 | The Magician | Strategic, pattern-aware | "What's the deeper pattern?" (L4-L5) |
| **SAGE** | 5000+ | The Sage | Teaching, meta-awareness | "How does this serve others?" (L5) |

---

## NARRATIVE ARCHETYPES

Each journal entry is classified by **archetype** to track the type of psychological work being done:

### 1. SHADOW WORK
**Definition:** Facing the parts of yourself you don't want to see (greed, fear, revenge impulses)

**Example Prompt:**
> "This trade scared me because it revealed that I still don't trust my system when volatility hits."

**Trigger Conditions:**
- `emotionTags` contain `fear`, `regret`, `revenge`
- `behaviorTags` contain `impulsive_entry`, `stop_moved`, `deviated_from_plan`

### 2. MENTOR MOMENT
**Definition:** Internalizing wisdom from discipline, systems, or community

**Example Prompt:**
> "I remembered [mentor/system/rule] and it kept me from chasing the pump. That's growth."

**Trigger Conditions:**
- `behaviorTags` contain `followed_plan`, `stop_respected`, `proper_size`
- `reflection.postTradeLessons` mentions "discipline", "rule", "system"

### 3. THRESHOLD CROSSING
**Definition:** Breaking through a psychological barrier (first time doing X correctly)

**Example Prompt:**
> "First time I took a full loss without feeling the need to revenge trade. This is new territory."

**Trigger Conditions:**
- First occurrence of a positive behavior in user's history
- User explicitly mentions "first time" or "breakthrough"

### 4. ORDEAL
**Definition:** Facing a major challenge (large loss, drawdown, near-capitulation moment)

**Example Prompt:**
> "This was brutal. I'm questioning everything. But I'm still here, still journaling. That counts."

**Trigger Conditions:**
- `pnl` exceeds -2x average loss
- `emotionTags` contain `frustration`, `regret`, `doubt`
- User mentions "worst trade", "biggest loss", "considering quitting"

### 5. RETURN WITH ELIXIR
**Definition:** Sharing insights with others, teaching, mentoring

**Example Prompt:**
> "I shared this pattern with the community. Helping others helps me solidify my own understanding."

**Trigger Conditions:**
- Entry set to `public` visibility
- `sharedToCommunity = true`
- Reflection includes teaching language ("I've learned", "my advice would be")

---

## REFLECTION PROMPT SYSTEM

### Prompt Structure (5 Layers)

Every journal entry is guided through **up to 5 layers of depth**:

#### **LAYER 1 (L1) — BASIC TRADE DATA**
*No prompts. Just data entry.*

```typescript
{
  symbol: "BTCUSDT",
  direction: "long",
  entry: 42000,
  exit: 43500,
  size: 0.1,
  pnl: 150,
  setupType: "breakout",
  timeframe: "5m"
}
```

**Status:** ✅ MINIMUM REQUIRED

---

#### **LAYER 2 (L2) — PRE-TRADE THOUGHTS**

**Prompt:**
> "Before entering this trade, what was your hypothesis? What setup did you see? What was your plan?"

**Purpose:** Capture intentionality (or lack thereof). Distinguish planned vs. impulsive entries.

**Example Response:**
> "I saw a clean breakout above 42k with volume. Plan was to enter on retest of 42k, stop at 41.5k, target 43.5k. Risk:Reward was 1:3."

**AI Detection:**
- If response mentions "plan", "hypothesis", "setup" → Tag as `planned_entry`
- If response is vague or missing → Tag as `impulsive_entry`

**Status:** ✅ ENCOURAGED (1.5x XP multiplier)

---

#### **LAYER 3 (L3) — EMOTIONS DURING TRADE**

**Prompt:**
> "How did you feel during this trade? Were you calm, anxious, excited, fearful? Did emotions influence your decisions?"

**Purpose:** Surface psychological state. Identify emotional triggers.

**Example Response:**
> "Felt confident at entry, but when it pulled back to my stop, I got nervous and moved it lower. That cost me—ended up stopping out at a worse level."

**AI Detection:**
- Emotion extraction: `confidence` → `fear` → `regret`
- Behavior tag: `stop_moved` (negative pattern)

**Status:** ✅ DEEPER REFLECTION (2x XP multiplier)

---

#### **LAYER 4 (L4) — POST-TRADE LESSONS**

**Prompt:**
> "What did you learn from this trade? What would you do differently next time? What pattern are you noticing?"

**Purpose:** Explicit lesson extraction. Forces meta-cognition.

**Example Response:**
> "Lesson: Don't move my stop based on fear. If I trust the setup enough to enter, I need to trust the stop. Moving it = fear-based decision = loss of edge."

**AI Detection:**
- Lesson clarity score (0-100 based on specificity)
- Pattern awareness: "Don't move stops" → Tag as `rule_identified`

**Status:** ✅ ADVANCED REFLECTION (3x XP multiplier)

---

#### **LAYER 5 (L5) — META-INSIGHTS & PATTERNS**

**Prompt:**
> "Zoom out: How does this trade fit into your broader journey? What deeper pattern are you seeing about yourself as a trader? What phase of the Hero's Journey are you in right now?"

**Purpose:** Narrative synthesis. Connect individual trades to the transformation arc.

**Example Response:**
> "I'm in the 'Tests & Trials' phase. I keep intellectually understanding that I need to trust my stops, but emotionally I'm still struggling. This is my shadow work—facing my fear of being wrong. Each time I journal this pattern, I get closer to breaking it."

**AI Detection:**
- Journey phase awareness: ✅ User explicitly mentions phase
- Pattern recognition depth: HIGH (connects emotion → behavior → consequence)
- Transformation score: 85/100

**Status:** ✅ MASTERY LEVEL (5x XP multiplier)

---

## EMOTION EXTRACTION ENGINE

### How AI Extracts Emotions from Reflection Text

```typescript
interface EmotionExtractionConfig {
  keywords: Record<EmotionTag, string[]>;
  compoundRules: {
    fomo: ['fear' && 'greed' && ('miss' || 'late' || 'fomo')],
    revenge: ['frustration' && 'greed' && ('revenge' || 'get back')],
    analysis_paralysis: ['doubt' && 'fear' && ('overthink' || 'paralyzed')]
  };
}

const EMOTION_KEYWORDS = {
  fear: ['scared', 'nervous', 'anxious', 'worried', 'panic', 'afraid'],
  greed: ['wanted more', 'greedy', 'chasing', 'overleverage', 'big win'],
  confidence: ['confident', 'certain', 'sure', 'trust', 'calm entry'],
  doubt: ['unsure', 'doubted', 'second-guess', 'hesitate', 'uncertain'],
  frustration: ['frustrated', 'annoyed', 'irritated', 'pissed', 'angry'],
  euphoria: ['euphoric', 'high', 'invincible', 'unstoppable', 'rush'],
  regret: ['regret', 'wish I', 'should have', 'mistake', 'if only'],
  calm: ['calm', 'neutral', 'zen', 'equanimity', 'detached', 'objective']
};

function extractEmotions(reflectionText: string): EmotionTag[] {
  const detected: EmotionTag[] = [];
  const lowerText = reflectionText.toLowerCase();
  
  // Check primary emotions
  for (const [emotion, keywords] of Object.entries(EMOTION_KEYWORDS)) {
    if (keywords.some(kw => lowerText.includes(kw))) {
      detected.push(emotion as EmotionTag);
    }
  }
  
  // Check compound emotions
  if (detected.includes('fear') && detected.includes('greed') && 
      (lowerText.includes('fomo') || lowerText.includes('miss'))) {
    detected.push('fomo');
  }
  
  if (detected.includes('frustration') && detected.includes('greed') &&
      (lowerText.includes('revenge') || lowerText.includes('get back'))) {
    detected.push('revenge');
  }
  
  if (detected.includes('doubt') && detected.includes('fear') &&
      (lowerText.includes('overthink') || lowerText.includes('paralyz'))) {
    detected.push('analysis_paralysis');
  }
  
  return detected;
}
```

---

## BEHAVIOR PATTERN DETECTION

### How AI Tags Behaviors from Entry Data + Reflection

```typescript
function detectBehaviors(entry: JournalEntry): BehaviorTag[] {
  const behaviors: BehaviorTag[] = [];
  const { trade, reflection } = entry;
  
  // ENTRY BEHAVIORS
  if (reflection.preTradeThoughts.length < 20) {
    behaviors.push('impulsive_entry'); // No plan documented
  } else {
    behaviors.push('planned_entry');
  }
  
  if (containsKeywords(reflection.duringTradeEmotions, ['fomo', 'late', 'miss'])) {
    behaviors.push('fomo_entry');
  }
  
  if (containsKeywords(reflection.duringTradeEmotions, ['revenge', 'get back', 'angry'])) {
    behaviors.push('revenge_entry');
  }
  
  // EXIT BEHAVIORS
  const holdTime = trade.exit.timestamp - trade.entry.timestamp;
  const avgHoldTime = getUserAverageHoldTime(entry.userId, trade.setupType);
  
  if (holdTime < avgHoldTime * 0.5) {
    behaviors.push('early_exit');
  } else if (holdTime > avgHoldTime * 2) {
    behaviors.push('held_too_long');
  }
  
  if (containsKeywords(reflection.duringTradeEmotions, ['moved stop', 'adjusted stop'])) {
    behaviors.push('stop_moved'); // Negative pattern
  } else if (trade.pnl < 0 && containsKeywords(reflection.postTradeLessons, ['respected', 'honored stop'])) {
    behaviors.push('stop_respected'); // Positive pattern
  }
  
  // RISK MANAGEMENT
  const accountSize = getUserAccountSize(entry.userId);
  const riskPercent = (trade.size * trade.entry) / accountSize;
  
  if (riskPercent > 0.02) behaviors.push('oversized');       // >2% risk
  else if (riskPercent < 0.005) behaviors.push('undersized'); // <0.5% risk
  else behaviors.push('proper_size');                         // 0.5-2% sweet spot
  
  // DISCIPLINE
  if (containsKeywords(reflection.postTradeLessons, ['followed', 'stuck to', 'plan worked'])) {
    behaviors.push('followed_plan');
  } else if (containsKeywords(reflection.postTradeLessons, ['deviated', 'broke rule', 'ignored'])) {
    behaviors.push('deviated_from_plan');
  } else if (reflection.preTradeThoughts.length < 20) {
    behaviors.push('no_plan');
  }
  
  return behaviors;
}
```

---

## TRANSFORMATION SCORING

### How AI Assesses Growth from Entries

```typescript
function calculateTransformationScore(entry: JournalEntry, userHistory: JournalEntry[]): number {
  let score = 0;
  
  // 1. PATTERN AWARENESS (+30 points)
  if (entry.reflection.metaInsights.includes('pattern') && 
      entry.reflection.metaInsights.length > 50) {
    score += 30;
  }
  
  // 2. EMOTIONAL HONESTY (+20 points)
  const emotionCount = entry.reflection.emotionTags.length;
  if (emotionCount >= 2) score += 20; // Multiple emotions = nuance
  
  // 3. BEHAVIORAL IMPROVEMENT (+30 points)
  const recentNegativeBehaviors = userHistory.slice(-10)
    .flatMap(e => e.reflection.behaviorTags)
    .filter(tag => ['impulsive_entry', 'stop_moved', 'oversized'].includes(tag));
  
  const currentPositiveBehaviors = entry.reflection.behaviorTags
    .filter(tag => ['planned_entry', 'stop_respected', 'proper_size'].includes(tag));
  
  if (currentPositiveBehaviors.length > 0 && recentNegativeBehaviors.length > 3) {
    score += 30; // Breaking negative pattern
  }
  
  // 4. DEPTH OF REFLECTION (+20 points)
  if (entry.reflection.reflectionDepth >= 4) {
    score += 20;
  }
  
  return Math.min(score, 100); // Cap at 100
}
```

---

## JOURNEY PHASE PROGRESSION

### How Users Advance Through Phases

```typescript
function updateJourneyPhase(user: UserProfile): JourneyPhase {
  const { xpTotal } = user;
  
  if (xpTotal >= 5000) return 'sage';
  if (xpTotal >= 2001) return 'master';
  if (xpTotal >= 501) return 'warrior';
  if (xpTotal >= 101) return 'seeker';
  return 'degen';
}

function getPhaseNarrative(phase: JourneyPhase): string {
  const narratives = {
    degen: "You're in the Ordinary World, driven by impulse and emotion. Your call to adventure is coming.",
    seeker: "You've crossed the threshold. You're questioning your patterns, seeking wisdom. Keep journaling.",
    warrior: "You're in the Tests & Trials phase. Discipline is your weapon. Consistency is your shield.",
    master: "You've approached the Inmost Cave. You see the patterns others miss. Soon, you'll teach.",
    sage: "You've returned with the elixir. Your wisdom serves others. You've integrated the lessons."
  };
  
  return narratives[phase];
}
```

---

## USER FLOW EXAMPLE

### Creating a Journal Entry (Frontend → Backend)

```typescript
// STEP 1: User enters trade data (L1)
const tradeData = {
  symbol: "ETHUSDT",
  direction: "long",
  entry: 2200,
  exit: 2150,
  size: 1,
  pnl: -50,
  setupType: "support_bounce",
  timeframe: "15m"
};

// STEP 2: System prompts for L2 (optional, but encouraged)
const prompt_L2 = "What was your hypothesis before entering this trade?";
const response_L2 = "I thought ETH would bounce at 2200 support. Plan was tight stop at 2180.";

// STEP 3: System prompts for L3 (emotion check)
const prompt_L3 = "How did you feel during this trade?";
const response_L3 = "Confident at entry, but when it broke 2200, I panicked and exited early. Turned out it did bounce—I just wasn't patient enough.";

// STEP 4: System prompts for L4 (lesson extraction)
const prompt_L4 = "What did you learn?";
const response_L4 = "I need to trust my stop. Exiting early based on fear = worse outcome than just honoring my plan.";

// STEP 5: System prompts for L5 (meta-insight, optional)
const prompt_L5 = "How does this fit your broader journey?";
const response_L5 = "This is my recurring pattern—fear of drawdown leads to early exits. I'm still in SEEKER phase, learning to trust my system.";

// BACKEND PROCESSING
const entry = await createJournalEntry({
  userId: user.id,
  trade: tradeData,
  reflection: {
    preTradeThoughts: response_L2,
    duringTradeEmotions: response_L3,
    postTradeLessons: response_L4,
    metaInsights: response_L5,
    
    // AI-extracted
    emotionTags: ['confidence', 'fear', 'regret'], // From L3 text
    behaviorTags: ['planned_entry', 'early_exit'], // From L2 + L3
    reflectionDepth: 5, // User completed all layers
    qualityScore: 85 // AI-assessed based on specificity & honesty
  },
  narrative: {
    journeyPhase: 'seeker', // User's current phase
    archetype: 'shadow_work', // Fear pattern identified
    transformationScore: 70 // Good awareness, still struggling
  }
});

// XP CALCULATION
const xpEarned = calculateXP(entry); // ~100 XP (L5 depth + quality + transformation)

// BADGE CHECK (handled by Layer 02)
await checkAndAwardBadges(user.id, entry);

// AI INSIGHTS (handled by Layer 03)
await generateAIInsights(user.id, entry);

// Return to user
return {
  entry,
  xpEarned,
  newTotalXP: user.xpTotal + xpEarned,
  phaseNarrative: getPhaseNarrative(user.journeyPhase)
};
```

---

## EXAMPLE ENTRIES BY DEPTH LEVEL

### L1 Entry (Basic — 10 XP)
```json
{
  "trade": {
    "symbol": "BTCUSDT",
    "direction": "long",
    "entry": 42000,
    "exit": 43000,
    "pnl": 100
  }
}
```

### L3 Entry (Emotions — 20 XP base)
```json
{
  "trade": { ... },
  "reflection": {
    "duringTradeEmotions": "Felt calm at entry, but got scared when it pulled back. Exited too early."
  }
}
```

### L5 Entry (Mastery — 50 XP base + bonuses)
```json
{
  "trade": { ... },
  "reflection": {
    "preTradeThoughts": "Clean breakout setup, 1:3 R:R, plan was to hold to target.",
    "duringTradeEmotions": "Felt confident, but fear crept in during pullback. Recognized it and stayed in.",
    "postTradeLessons": "This is the first time I've successfully stayed in during fear. Growth.",
    "metaInsights": "I'm transitioning from SEEKER to WARRIOR. My discipline is solidifying. Shadow work is paying off."
  }
}
```

---

## INTEGRATION WITH OTHER LAYERS

### → Layer 02 (Badges)
- Depth level determines XP multiplier
- Transformation score contributes to "Growth" badges
- Archetype completion unlocks narrative badges

### → Layer 03 (AI Insights)
- Emotion/behavior tags feed pattern detection
- Cross-entry analysis identifies recurring themes
- AI recommendations prioritize areas needing work

### → Layer 04 (Community)
- High-quality L5 entries featured in community feed
- Anonymized archetypes shared to heatmaps
- Users can opt to make entries public for teaching

---

## KEY METRICS TO TRACK

```typescript
interface HeroJourneyMetrics {
  // PROGRESSION
  journeyPhase: JourneyPhase;
  xpTotal: number;
  level: number;
  
  // REFLECTION QUALITY
  avgReflectionDepth: number;        // 1-5 average
  avgQualityScore: number;           // 0-100 average
  avgTransformationScore: number;    // 0-100 average
  
  // CONSISTENCY
  streakCurrent: number;
  streakLongest: number;
  entriesThisWeek: number;
  entriesTotal: number;
  
  // ARCHETYPE DISTRIBUTION
  archetypeCount: {
    shadow_work: number;
    mentor_moment: number;
    threshold_crossing: number;
    ordeal: number;
    return_with_elixir: number;
  };
  
  // EMOTIONAL AWARENESS
  emotionDiversity: number;          // Unique emotions tagged
  mostCommonEmotion: EmotionTag;
  mostCommonBehavior: BehaviorTag;
}
```

---

## PROMPT TEMPLATES FOR FRONTEND

### Quick Entry (Mobile-Optimized)
```
1. What happened? (trade data)
2. How did you feel? (emotion check)
3. What's the lesson? (quick insight)
```

### Deep Dive (Desktop, Post-Session Review)
```
1. Trade Data (L1)
2. Pre-Trade Plan (L2)
3. Emotional State During (L3)
4. Post-Trade Analysis (L4)
5. Bigger Picture Insight (L5)
```

### Voice Input (Experimental)
```
"Just talk through the trade. I'll extract the data, emotions, and lessons."
→ AI transcribes + structures into L1-L5 format
```

---

## FINAL NOTES

This layer is the **heart** of the journal system. Without narrative reflection, it's just a trade log. With it, it becomes a **transformation engine**.

The goal is to make users feel like they're writing their own hero's story—not just tracking P&L, but tracking **who they're becoming**.

**STATUS**: ✅ Layer 01 Complete | Ready for Layer 02 Integration
