# 00 — GLOBAL SCHEMA & DATA TAXONOMY

## PURPOSE

This document defines the **master data model**, **naming conventions**, **cross-feature data flow**, and **prompt routing logic** for the entire Sparkfined Journal System. All other feature layers (01-04) inherit from this schema.

---

## CORE PHILOSOPHY

The Sparkfined Journal System is built on three foundational principles:

1. **Narrative-Driven Growth** — Every trade is a chapter in the trader's Hero's Journey
2. **Quality over Quantity** — Reflection depth and analysis quality matter more than P&L
3. **Community Amplification** — Collective learning accelerates individual transformation

---

## GLOBAL DATA MODEL

### User Profile Schema

```typescript
interface UserProfile {
  userId: string;                    // UUID
  username: string;
  journeyPhase: JourneyPhase;        // DEGEN | SEEKER | WARRIOR | MASTER | SAGE
  xpTotal: number;
  level: number;
  badgesEarned: Badge[];
  streakCurrent: number;
  streakLongest: number;
  joinedAt: timestamp;
  preferences: {
    reflectionStyle: 'quick' | 'deep' | 'narrative';
    privacyMode: 'private' | 'anonymous' | 'public';
    aiInsightsEnabled: boolean;
    communityShareEnabled: boolean;
  };
}

enum JourneyPhase {
  DEGEN = 'degen',           // 0-100 XP — Impulsive, reactive
  SEEKER = 'seeker',         // 101-500 XP — Beginning to question patterns
  WARRIOR = 'warrior',       // 501-2000 XP — Disciplined, consistent
  MASTER = 'master',         // 2001-5000 XP — Strategic, pattern-aware
  SAGE = 'sage'              // 5000+ XP — Teaching others, meta-awareness
}
```

### Journal Entry Schema

```typescript
interface JournalEntry {
  entryId: string;                   // UUID
  userId: string;
  timestamp: timestamp;
  
  // TRADE DATA (L1 — Basic)
  trade: {
    symbol: string;
    direction: 'long' | 'short';
    entry: number;
    exit: number;
    size: number;
    pnl: number;
    riskReward: number;
    setupType: string;               // e.g., "breakout", "reversal", "pullback"
    timeframe: string;               // e.g., "1m", "5m", "1h"
  };
  
  // REFLECTION DATA (L2-L5 — Depth Layers)
  reflection: {
    preTradeThoughts: string;        // L2 — What was your hypothesis?
    duringTradeEmotions: string;     // L3 — How did you feel?
    postTradeLessons: string;        // L4 — What did you learn?
    metaInsights: string;            // L5 — How does this fit your broader pattern?
    
    emotionTags: EmotionTag[];       // AI-extracted or user-selected
    behaviorTags: BehaviorTag[];     // AI-detected patterns
    
    reflectionDepth: 1 | 2 | 3 | 4 | 5;  // Depth score (L1-L5)
    qualityScore: number;            // 0-100 AI-assessed quality
  };
  
  // NARRATIVE CONTEXT (Hero's Journey Mapping)
  narrative: {
    journeyPhase: JourneyPhase;      // User's phase at time of entry
    archetype: Archetype;            // e.g., "shadow_work", "mentor_moment"
    transformationScore: number;     // 0-100 — How much growth shown?
  };
  
  // BADGES & PROGRESSION
  badgesAwarded: Badge[];            // Earned from this entry
  xpEarned: number;
  
  // PRIVACY & SHARING
  visibility: 'private' | 'anonymous' | 'public';
  sharedToCommunity: boolean;
  
  // AI INSIGHTS (Generated Post-Entry)
  aiInsights: {
    patternDetected: string[];       // e.g., ["revenge_trading", "fomo_entry"]
    suggestedFocus: string;          // Personalized recommendation
    similarPastTrades: string[];     // Entry IDs of similar trades
    confidenceScore: number;         // 0-100 AI confidence
  };
}
```

### Badge Schema

```typescript
interface Badge {
  badgeId: string;
  name: string;
  tier: 'bronze' | 'silver' | 'gold' | 'diamond';
  category: BadgeCategory;
  description: string;
  xpValue: number;
  unlockedAt: timestamp;
  onChain: boolean;                  // NFT minted?
  
  // Unlock Criteria
  criteria: {
    type: 'streak' | 'quality' | 'insight' | 'community' | 'transformation';
    threshold: number;
    metric: string;                  // e.g., "reflection_depth", "pattern_awareness"
  };
}

enum BadgeCategory {
  CONSISTENCY = 'consistency',       // Streak-based
  DEPTH = 'depth',                   // Reflection quality
  AWARENESS = 'awareness',           // Pattern recognition
  GROWTH = 'growth',                 // Transformation arc
  COMMUNITY = 'community'            // Social learning
}
```

### Emotion & Behavior Taxonomy

```typescript
enum EmotionTag {
  // PRIMARY EMOTIONS
  FEAR = 'fear',
  GREED = 'greed',
  CONFIDENCE = 'confidence',
  DOUBT = 'doubt',
  FRUSTRATION = 'frustration',
  EUPHORIA = 'euphoria',
  REGRET = 'regret',
  CALM = 'calm',
  
  // COMPOUND STATES
  FOMO = 'fomo',                     // Fear + Greed
  REVENGE = 'revenge',               // Frustration + Greed
  ANALYSIS_PARALYSIS = 'analysis_paralysis'  // Doubt + Fear
}

enum BehaviorTag {
  // ENTRY BEHAVIORS
  IMPULSIVE_ENTRY = 'impulsive_entry',
  PLANNED_ENTRY = 'planned_entry',
  FOMO_ENTRY = 'fomo_entry',
  REVENGE_ENTRY = 'revenge_entry',
  
  // EXIT BEHAVIORS
  EARLY_EXIT = 'early_exit',
  HELD_TOO_LONG = 'held_too_long',
  STOP_RESPECTED = 'stop_respected',
  STOP_MOVED = 'stop_moved',
  
  // RISK MANAGEMENT
  OVERSIZED = 'oversized',
  UNDERSIZED = 'undersized',
  PROPER_SIZE = 'proper_size',
  
  // DISCIPLINE
  FOLLOWED_PLAN = 'followed_plan',
  DEVIATED_FROM_PLAN = 'deviated_from_plan',
  NO_PLAN = 'no_plan'
}
```

---

## CROSS-FEATURE DATA FLOW

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER CREATES ENTRY                       │
└─────────────────────────────┬───────────────────────────────────┘
                              │
                ┌─────────────┴─────────────┐
                │                           │
         ┌──────▼──────┐            ┌──────▼──────┐
         │ 01: HERO'S  │            │ 02: TIERED  │
         │  JOURNEY    │            │   UNLOCK    │
         │  (Narrative)│            │  (Badges)   │
         └──────┬──────┘            └──────┬──────┘
                │                           │
                │     ┌─────────────────────┘
                │     │
         ┌──────▼─────▼─────┐
         │  03: AI INSIGHTS │
         │  (Pattern Recog) │
         └──────┬───────────┘
                │
         ┌──────▼──────┐
         │ 04: SOCIAL  │
         │   PROOF     │
         │ (Community) │
         └─────────────┘
```

### Flow Logic

1. **Entry Creation** → Routes to Layer 01 (Hero's Journey)
   - Narrative prompts guide reflection
   - Emotion/behavior tags extracted
   - Depth level assessed (L1-L5)

2. **Quality Scoring** → Routes to Layer 02 (Tiered Unlock)
   - XP calculated based on quality + depth
   - Badges evaluated and awarded
   - Progression updated

3. **Pattern Analysis** → Routes to Layer 03 (AI Insights)
   - Entry analyzed against historical patterns
   - Insights generated
   - Recommendations surfaced

4. **Community Aggregation** → Routes to Layer 04 (Social Proof)
   - If user opts in: anonymized data shared
   - Heatmaps updated
   - Community insights generated

---

## NAMING CONVENTIONS

### File Naming
- **Snake case** for all system files: `journal_entry.ts`, `badge_system.ts`
- **Pascal case** for components: `JournalEntryCard.tsx`, `BadgeDisplay.tsx`

### Database Collections/Tables
- **Plural, snake_case**: `journal_entries`, `user_profiles`, `badges`, `community_heatmaps`

### API Endpoints
- **RESTful, kebab-case**: 
  - `POST /api/journal/entries`
  - `GET /api/journal/entries/:entryId`
  - `GET /api/badges/earned`
  - `POST /api/community/share`

### Event Names (for logging/analytics)
- **Domain-prefixed, snake_case**:
  - `journal_entry_created`
  - `badge_earned`
  - `ai_insight_generated`
  - `community_data_shared`

---

## PROMPT ROUTING LOGIC

### When User Interacts With Journal

```typescript
// Routing Decision Tree
function routePrompt(userAction: string, context: Context): PromptLayer {
  
  // LAYER 01: NARRATIVE & REFLECTION
  if (userAction.includes('create_entry') || 
      userAction.includes('reflect') ||
      userAction.includes('emotion')) {
    return 'LAYER_01_HEROS_JOURNEY';
  }
  
  // LAYER 02: PROGRESSION & BADGES
  if (userAction.includes('badges') ||
      userAction.includes('level') ||
      userAction.includes('unlock') ||
      userAction.includes('streak')) {
    return 'LAYER_02_TIERED_UNLOCK';
  }
  
  // LAYER 03: AI INSIGHTS & PATTERNS
  if (userAction.includes('pattern') ||
      userAction.includes('insight') ||
      userAction.includes('similar_trades') ||
      userAction.includes('ai_feedback')) {
    return 'LAYER_03_AI_INSIGHTS';
  }
  
  // LAYER 04: COMMUNITY & SHARING
  if (userAction.includes('community') ||
      userAction.includes('heatmap') ||
      userAction.includes('share') ||
      userAction.includes('compare')) {
    return 'LAYER_04_SOCIAL_PROOF';
  }
  
  // DEFAULT: Route to appropriate layer based on user's journey phase
  return determineLayerByPhase(context.user.journeyPhase);
}
```

---

## XP & PROGRESSION FORMULA

### XP Calculation

```typescript
function calculateXP(entry: JournalEntry): number {
  let baseXP = 10; // Every entry gets 10 XP minimum
  
  // DEPTH MULTIPLIER (L1-L5)
  const depthMultiplier = {
    1: 1.0,   // Basic trade data only
    2: 1.5,   // + Pre-trade thoughts
    3: 2.0,   // + Emotions during trade
    4: 3.0,   // + Post-trade lessons
    5: 5.0    // + Meta-insights & patterns
  };
  
  baseXP *= depthMultiplier[entry.reflection.reflectionDepth];
  
  // QUALITY BONUS (AI-assessed quality 0-100)
  const qualityBonus = entry.reflection.qualityScore * 0.5; // Max +50 XP
  
  // CONSISTENCY BONUS (streak multiplier)
  const streakBonus = Math.min(user.streakCurrent * 2, 50); // Max +50 XP
  
  // TRANSFORMATION BONUS (meaningful growth shown)
  const transformationBonus = entry.narrative.transformationScore * 0.3; // Max +30 XP
  
  // TOTAL
  return Math.floor(baseXP + qualityBonus + streakBonus + transformationBonus);
}
```

### Level Thresholds

```typescript
const LEVEL_THRESHOLDS = {
  1: 0,       // Starting level
  2: 100,
  3: 250,
  4: 500,
  5: 1000,
  10: 2000,   // WARRIOR phase begins
  15: 5000,   // MASTER phase begins
  20: 10000,  // SAGE phase begins
  // ... exponential curve continues
};

function calculateLevel(totalXP: number): number {
  return Object.entries(LEVEL_THRESHOLDS)
    .reverse()
    .find(([_, threshold]) => totalXP >= threshold)?.[0] || 1;
}
```

---

## PRIVACY & ANONYMIZATION

### Data Sharing Levels

```typescript
enum VisibilityMode {
  PRIVATE = 'private',           // Only user can see
  ANONYMOUS = 'anonymous',       // Shared to community without identifiers
  PUBLIC = 'public'              // Shared with username/profile
}

interface AnonymizedEntry {
  // INCLUDED (Aggregated for Heatmaps)
  setupType: string;
  emotionTags: EmotionTag[];
  behaviorTags: BehaviorTag[];
  reflectionDepth: number;
  journeyPhase: JourneyPhase;
  pnlCategory: 'win' | 'loss' | 'breakeven';
  
  // EXCLUDED (Never Shared)
  userId: never;
  username: never;
  pnl: never;               // Absolute values not shared
  symbol: never;            // Specific trades not shared
  entry: never;
  exit: never;
}
```

---

## INTEGRATION POINTS

### External Systems

1. **TradingView Lightweight Charts**
   - Trade markers synced to journal entries
   - Replay mode highlights journaled trades
   - Emotion overlays on chart timeline

2. **AI Signal System**
   - Signals can trigger "pre-trade reflection" prompts
   - AI recommendations cross-referenced with journal patterns
   - Signal performance tracked against journal quality

3. **NFT/Token System**
   - Diamond-tier badges → NFT minting trigger
   - Token lock → unlocks exclusive journal features
   - On-chain achievement verification

4. **Community Dashboard**
   - Aggregated heatmaps from Layer 04
   - Leaderboards (opt-in, anonymized)
   - Collective wisdom insights

---

## ERROR HANDLING & VALIDATION

### Entry Validation Rules

```typescript
const VALIDATION_RULES = {
  // REQUIRED FIELDS (L1 Minimum)
  trade: {
    symbol: { required: true, minLength: 1 },
    direction: { required: true, enum: ['long', 'short'] },
    entry: { required: true, type: 'number' },
    exit: { required: true, type: 'number' },
    pnl: { required: true, type: 'number' }
  },
  
  // OPTIONAL BUT ENCOURAGED (L2-L5)
  reflection: {
    preTradeThoughts: { minLength: 20, maxLength: 5000 },
    duringTradeEmotions: { minLength: 10, maxLength: 2000 },
    postTradeLessons: { minLength: 20, maxLength: 3000 },
    metaInsights: { minLength: 30, maxLength: 2000 }
  }
};

function validateEntry(entry: JournalEntry): ValidationResult {
  const errors = [];
  
  // Check L1 requirements
  if (!entry.trade.symbol) errors.push('Symbol is required');
  if (!entry.trade.direction) errors.push('Direction is required');
  
  // Assess reflection depth
  const depthScore = assessReflectionDepth(entry.reflection);
  
  return {
    isValid: errors.length === 0,
    errors,
    reflectionDepth: depthScore,
    warnings: generateReflectionWarnings(depthScore)
  };
}
```

---

## MIGRATION & VERSIONING

### Schema Versioning

```typescript
interface SchemaVersion {
  version: string;           // e.g., "1.0.0"
  migrationsApplied: string[];
  compatibleWith: string[];  // Backward compatibility range
}

// Current Version
const CURRENT_SCHEMA_VERSION = "1.0.0";

// Future migrations will be tracked here
const MIGRATIONS = {
  "1.0.0_to_1.1.0": migrateAddCommunityFeatures,
  "1.1.0_to_2.0.0": migrateRefactorBadgeSystem
};
```

---

## PERFORMANCE CONSIDERATIONS

### Caching Strategy

```typescript
// HOT DATA (Redis/In-Memory)
- User profile & current streak
- Recent entries (last 7 days)
- Badge progress for active quests

// WARM DATA (Database with indexing)
- Full journal history (paginated)
- Badge definitions & criteria
- AI insights & patterns

// COLD DATA (S3/Blob Storage)
- Archived entries (>1 year old)
- Community heatmap historical snapshots
- AI model training data
```

### Query Optimization

```sql
-- Key Indexes for Performance
CREATE INDEX idx_user_entries ON journal_entries(userId, timestamp DESC);
CREATE INDEX idx_emotion_tags ON journal_entries USING GIN(emotionTags);
CREATE INDEX idx_journey_phase ON user_profiles(journeyPhase);
CREATE INDEX idx_badge_criteria ON badges(category, tier);
```

---

## NEXT STEPS

This global schema serves as the **foundation** for all feature layers:

1. **Layer 01 (Hero's Journey)** → Implements narrative prompts & reflection flow
2. **Layer 02 (Tiered Unlock)** → Implements badge system & XP progression
3. **Layer 03 (AI Insights)** → Implements pattern detection & recommendations
4. **Layer 04 (Social Proof)** → Implements community heatmaps & sharing

All layers **inherit** data models, naming conventions, and routing logic from this schema.

---

**STATUS**: ✅ Global Schema Complete | Ready for Layer 01 Implementation
