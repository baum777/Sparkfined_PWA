# 04 — SOCIAL PROOF & COMMUNITY LEARNING LAYER

## PURPOSE
Aggregate anonymized journal data to create community insights, heatmaps, and collective wisdom that helps individual traders learn from the crowd while maintaining privacy.

---

## CORE FEATURES

### 1. COMMUNITY HEATMAPS
Visual representation of:
- Most common emotional states by market condition
- Setup types with highest community success
- Time-of-day performance patterns
- Common mistakes during volatile periods

### 2. ANONYMIZED SHARING
Users can opt to share:
- Emotion/behavior patterns (NOT specific trades/P&L)
- Reflection depth levels
- Journey phase distribution
- Badge achievements (leaderboard opt-in)

### 3. COLLECTIVE INSIGHTS
AI aggregates across users to surface:
- "80% of traders feel FOMO during sharp rallies"
- "Community performs 20% better on breakouts vs reversals"
- "Most consistent journalers are in WARRIOR phase"

---

## DATA ANONYMIZATION

```typescript
interface AnonymizedContribution {
  // INCLUDED
  setupType: string;
  emotionTags: EmotionTag[];
  behaviorTags: BehaviorTag[];
  reflectionDepth: 1 | 2 | 3 | 4 | 5;
  journeyPhase: JourneyPhase;
  pnlCategory: 'win' | 'loss' | 'breakeven';  // NOT absolute value
  timestamp: timestamp;                       // For time-of-day analysis
  
  // NEVER SHARED
  userId: never;
  username: never;
  pnl: never;
  symbol: never;
  entry: never;
  exit: never;
}
```

---

## COMMUNITY HEATMAP TYPES

### Emotion Heatmap
```
TIME OF DAY vs EMOTION FREQUENCY

          FEAR    GREED   CONFIDENCE   FOMO
Asian     20%     10%     50%          20%
London    35%     15%     40%          10%
NY Open   50%     30%     15%          5%
NY Close  25%     20%     45%          10%
```

### Setup Performance Heatmap
```
SETUP TYPE vs COMMUNITY WIN RATE

Breakout       65% (500 trades)
Pullback       58% (320 trades)
Reversal       42% (180 trades)
Range Bound    51% (240 trades)
```

---

## PRIVACY CONTROLS

```typescript
interface CommunitySettings {
  contribute: boolean;                 // Opt-in to share anonymized data
  viewHeatmaps: boolean;               // Can view community insights
  publicProfile: boolean;              // Username visible on leaderboards
  shareInsights: boolean;              // Share L4-L5 reflections publicly
}
```

**Default: All FALSE (explicit opt-in required)**

---

## INTEGRATION

### → Layer 01: Anonymized archetypes contribute to community patterns
### → Layer 02: Community badges for high-value contributors
### → Layer 03: AI insights informed by collective patterns

**STATUS**: ✅ Layer 04 Complete | Community Learning Defined
