# SUB-PROMPTS: Social Proof Layer (Layer 04)

## SP-04-01: Community Heatmap Display
**PROMPT:**
```
📊 COMMUNITY INSIGHTS

**Emotion Distribution (Last 7 Days)**
FOMO: 32% | Fear: 28% | Confidence: 22% | Greed: 18%

**Best Performing Setups**
1. Breakouts: 65% win rate (500 trades)
2. Pullbacks: 58% win rate (320 trades)

**Peak Journaling Time**
Most active: 6-8pm UTC (after NY close)

[View Full Heatmaps →]
```

## SP-04-02: Opt-In to Contribute
**PROMPT:**
```
🤝 CONTRIBUTE TO COMMUNITY LEARNING

Your anonymized patterns can help other traders.

**What's shared:** Emotions, setups, behaviors (patterns only)
**What's NEVER shared:** Your identity, P&L, specific trades

[Enable Contribution] [Learn More] [Maybe Later]
```

**STATUS**: ✅ Layer 04 Sub-Prompts Complete
