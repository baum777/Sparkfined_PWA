export { useQuickLog } from "./useQuickLog";
